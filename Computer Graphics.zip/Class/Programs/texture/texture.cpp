
#include <cmath>
#include <iostream>
using namespace std;
#include <gl\glut.h>			// Header File For The OpenGL32 Library
#include <gl\glu.h>			// Header File For The GLu32 Library
#include <gl\glaux.h>

GLuint texture[6];

const int windowHeight = 640;
const int windowWidth = 800;

int walltext;
int floortext;

// this loads a bitmap
// it takes the bitmaps filename
// it returns the bitmap upon success else returns NULL
AUX_RGBImageRec* LoadBMP(  char strFName[] )
{
	AUX_RGBImageRec* pBitmap = NULL;

      if ( strFName == NULL || !strcmp( strFName, "" ) )
            return NULL;

      // load the bitmap
	pBitmap = auxDIBImageLoad( strFName );

	// return the bitmap
      return pBitmap;
} // end LoadBMP

// this frees a loaded bitmap loaded from LoadBMP
// it takes the bitmap struct
// it returns true upon success else returns false
bool DestroyBMP( AUX_RGBImageRec* pBitmap )
{
      if ( !pBitmap )
            return false;

      // free the bitmap
      free( pBitmap );
      pBitmap = NULL;

      return true;
} // end DestroyBMP




void wall()
{
	glPushMatrix();
	glDisable(GL_LIGHTING);
	glBindTexture(GL_TEXTURE_2D, texture[walltext]);

	glBegin(GL_POLYGON);
		glTexCoord2f(10.0f, 10.0f);glVertex3f(50.0f, 1.0f, -50.0f);
		glTexCoord2f(0.0f, 10.0f);glVertex3f(-50.0f, 1.0f, -50.0f);
		glTexCoord2f(0.0f, 0.0f);glVertex3f(-50.0f, 50.0f, -50.0f);
		glTexCoord2f(10.0f, 0.0f);glVertex3f(50.0f, 50.0f, -50.0f);
	glEnd();

	glEnable(GL_LIGHTING);
	glPopMatrix();
}

void floor()
{
	glPushMatrix();
	glDisable(GL_LIGHTING);
	glBindTexture(GL_TEXTURE_2D, texture[floortext]);
	
	glBegin(GL_POLYGON);
		glTexCoord2f(0.0f, 10.0f); glVertex3f(-50.0f,  1.0f, -50.0f);	// Point 1 (Top)
		glTexCoord2f(0.0f, 0.0f); glVertex3f(-50.0f,  1.0f,  50.0f);	// Point 2 (Top)
		glTexCoord2f(10.0f, 0.0f); glVertex3f( 50.0f,  1.0f,  50.0f);	// Point 3 (Top)
		glTexCoord2f(10.0f, 10.0f); glVertex3f( 50.0f,  1.0f, -50.0f);	// Point 4 (Top)
	glEnd();

	glEnable(GL_LIGHTING);
	glPopMatrix();
}


void display()
{	
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glLoadIdentity();
	
	glPushMatrix();
		glEnable(GL_TEXTURE_2D);
		glTranslatef(0, -2, 0);
		floor();
		wall();
		glDisable(GL_TEXTURE_2D);
	glPopMatrix();

	glutSwapBuffers();
}

void initTextures()
{
	AUX_RGBImageRec *TextureImage[6];			// Create Storage Space For The Texture
	memset(TextureImage,0,sizeof(void *)*1);    // Set The Pointer To NULL

	// Load The Bitmap, Check For Errors, If Bitmap's Not Found Quit
	if (TextureImage[0]=LoadBMP("wood.bmp"))
	{				
		glGenTextures(1, &texture[0]);					// Create The Texture

		// Typical Texture Generation Using Data From The Bitmap
		glBindTexture(GL_TEXTURE_2D, texture[0]);
		
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
		glTexImage2D(GL_TEXTURE_2D, 0, 3, TextureImage[0]->sizeX, TextureImage[0]->sizeY, 0, GL_RGB, GL_UNSIGNED_BYTE, TextureImage[0]->data);
	}

	// Load The Bitmap, Check For Errors, If Bitmap's Not Found Quit
	if (TextureImage[1]=LoadBMP("brick.bmp"))
	{				
		glGenTextures(1, &texture[1]);					// Create The Texture

		// Typical Texture Generation Using Data From The Bitmap
		glBindTexture(GL_TEXTURE_2D, texture[1]);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
		glTexImage2D(GL_TEXTURE_2D, 0, 3, TextureImage[1]->sizeX, TextureImage[1]->sizeY, 0, GL_RGB, GL_UNSIGNED_BYTE, TextureImage[1]->data);
	}

	if (TextureImage[2]=LoadBMP("grid.bmp"))
	{				
		glGenTextures(1, &texture[2]);					// Create The Texture

		// Typical Texture Generation Using Data From The Bitmap
		glBindTexture(GL_TEXTURE_2D, texture[2]);
		glTexImage2D(GL_TEXTURE_2D, 0, 3, TextureImage[2]->sizeX, TextureImage[2]->sizeY, 0, GL_RGB, GL_UNSIGNED_BYTE, TextureImage[2]->data);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
	}
	if (TextureImage[3]=LoadBMP("grass.bmp"))
	{				
		glGenTextures(1, &texture[3]);					// Create The Texture

		// Typical Texture Generation Using Data From The Bitmap
		glBindTexture(GL_TEXTURE_2D, texture[3]);
		glTexImage2D(GL_TEXTURE_2D, 0, 3, TextureImage[3]->sizeX, TextureImage[3]->sizeY, 0, GL_RGB, GL_UNSIGNED_BYTE, TextureImage[3]->data);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
	}
	if (TextureImage[4]=LoadBMP("cloth.bmp"))
	{				
		glGenTextures(1, &texture[4]);					// Create The Texture

		// Typical Texture Generation Using Data From The Bitmap
		glBindTexture(GL_TEXTURE_2D, texture[4]);
		glTexImage2D(GL_TEXTURE_2D, 0, 3, TextureImage[4]->sizeX, TextureImage[4]->sizeY, 0, GL_RGB, GL_UNSIGNED_BYTE, TextureImage[4]->data);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
	}
	if (TextureImage[5]=LoadBMP("rock.bmp"))
	{				
		glGenTextures(1, &texture[5]);					// Create The Texture

		// Typical Texture Generation Using Data From The Bitmap
		glBindTexture(GL_TEXTURE_2D, texture[5]);
		glTexImage2D(GL_TEXTURE_2D, 0, 3, TextureImage[5]->sizeX, TextureImage[5]->sizeY, 0, GL_RGB, GL_UNSIGNED_BYTE, TextureImage[5]->data);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
	}

	for(int i = 0; i < 6; i++)
		if (TextureImage[i])									// If Texture Exists
		{
			if (TextureImage[i]->data)							// If Texture Image Exists
			{
				free(TextureImage[i]->data);					// Free The Texture Image Memory
			}
			free(TextureImage[i]);								// Free The Image Structure
		}
}

void init()
{
	cout << "Enter the texture number for the wall and the floor:\n ";
	cout << "  0 is wood\n   1 is brick\n   2 is a grid\n";
	cout << "   3 is grass/dirt\n   4 is brown cloth\n   5 is rock\n";
	cin >> walltext >> floortext;

	initTextures();

	glClearColor(1.0, 1.0, 1.0, 1);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	//Establish the view
	gluPerspective(40.0,(GLdouble)windowWidth/(GLdouble)windowHeight,0.5,500.0);
	glMatrixMode(GL_MODELVIEW);

	glEnable(GL_DEPTH_TEST);
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);
	glShadeModel(GL_SMOOTH);
	// set the light source properties
	GLfloat light_position [] = {0, 60, 13, 0.0f};
	glLightfv(GL_LIGHT0, GL_POSITION, light_position);

	glEnable(GL_TEXTURE_2D);
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);
}

int main(int argc, char** argv)
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
	glutInitWindowSize(windowWidth,windowHeight);
	glutInitWindowPosition(0,0);
	glutCreateWindow("Texture Example");
	glutDisplayFunc(display);
	init();
	glutMainLoop();
}