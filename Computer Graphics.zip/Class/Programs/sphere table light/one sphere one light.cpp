#include <stdlib.h>
#include <iostream>
#include <cmath>
#include <GL/glut.h>
using namespace std;

bool drawsphere = true;
GLfloat position[] = { 1.0, 1.0, 1.0, 0.0 };
bool lighton = true;

void init(void)
{
   GLfloat ambient[] = { 0.0, 0.0, 0.0, 1.0 };
   GLfloat diffuse[] = { 1.0, 1.0, 1.0, 1.0 };
   GLfloat lmodel_ambient[] = { 0.4, 0.4, 0.4, 1.0 };
   GLfloat local_view[] = { 0.0 };

   glClearColor(0.0, 0.1, 0.1, 0.0);
   glEnable(GL_DEPTH_TEST);
   glShadeModel(GL_SMOOTH);

   glLightfv(GL_LIGHT0, GL_AMBIENT, ambient);
   glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuse);
   glLightfv(GL_LIGHT0, GL_POSITION, position);
   glLightModelfv(GL_LIGHT_MODEL_AMBIENT, lmodel_ambient);
   glLightModelfv(GL_LIGHT_MODEL_LOCAL_VIEWER, local_view);
   glEnable(GL_LIGHTING);
   glEnable(GL_LIGHT0);
}


void display(void)
{
   GLfloat no_mat[] = { 0.0, 0.0, 0.0, 1.0 };
   GLfloat high_mat[] = { 1.0, 0.0, 0.0, 1.0 };
   GLfloat mat_ambient[] = { 0.7, 0.7, 0.7, 1.0 };
   GLfloat mat_ambient_color[] = { 0.8, 0.8, 0.2, 1.0 };
   GLfloat mat_diffuse[] = { 0.1, 0.5, 0.8, 1.0 };
   GLfloat mat_specular[] = { 1.0, 1.0, 1.0, 1.0 };
   GLfloat no_shininess[] = { 0.0 };
   GLfloat low_shininess[] = { 5.0 };
   GLfloat high_shininess[] = { 100.0 };
   GLfloat mat_emission[] = {0.3, 0.2, 0.2, 0.0};

   glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
   glLoadIdentity();
//   gluLookAt(0, 2, 0, 0, 0, 0, -1, 0, 0);
//  draw sphere at origin
   if (drawsphere)
   {
	   	glColor3f(0,1,0);		//Color is green?
		glPushMatrix();
		glMaterialfv(GL_FRONT, GL_AMBIENT, mat_ambient);
		glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse);
		glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
		glMaterialfv(GL_FRONT, GL_SHININESS, high_shininess);
		glMaterialfv(GL_FRONT, GL_EMISSION, no_mat);
		glutSolidSphere(1, 16, 16);
		glPopMatrix();
   }

   //the table top 1 unit below the sphere 
   glPushMatrix();
   glColor3f(1,1,1);		//Color is white?
   glMaterialfv(GL_FRONT, GL_AMBIENT, mat_ambient);
   glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse);
   glMaterialfv(GL_FRONT, GL_SPECULAR, no_mat);
   glMaterialfv(GL_FRONT, GL_SHININESS, no_shininess);
   glMaterialfv(GL_FRONT, GL_EMISSION, mat_emission);
	glTranslatef(0,-2,0);
	glRotatef(5,0,0,1);
	glScalef(8, .3, 8);
	glutSolidCube(1);
   glPopMatrix();

   //Draw a "cylinder"
   glPushMatrix();
   glColor3f(1,1,1);		//Color is white?
   glMaterialfv(GL_FRONT, GL_AMBIENT, mat_ambient);
   glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse);
   glMaterialfv(GL_FRONT, GL_SPECULAR, no_mat);
   glMaterialfv(GL_FRONT, GL_SHININESS, no_shininess);
   glMaterialfv(GL_FRONT, GL_EMISSION, mat_emission);
   glTranslatef(2, 1.0, 1);
   glEnable(GL_NORMALIZE) ;
   glBegin( GL_QUAD_STRIP);
		double t = 0.0;   
		int nslice = 10;
		double dt = (360./ nslice) * 3.1416 / 180.;
		for  (int j = 0; j <= nslice; ++j) {          
			glNormal3f(cos(t), 0., sin(t));
			glVertex3f(cos(t), 0., sin(t));
			glVertex3f(cos(t), 2., sin(t));
			t = t + dt;
		}
	glEnd();
	glPopMatrix();

   //the line
   glPushMatrix();
   glColor3f(0,0,1);		//Color is blue?
   glMaterialfv(GL_FRONT, GL_AMBIENT, mat_ambient);
   glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse);
   glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
   glMaterialfv(GL_FRONT, GL_SHININESS, high_shininess);
   glMaterialfv(GL_FRONT, GL_EMISSION, high_mat);
   glLineWidth(5);
   glBegin(GL_LINES);
	   glVertex3f(4,4,4);
	   glVertex3f(0,0,0);
   glEnd();
   glPopMatrix();
   glutSwapBuffers();
}

void reshape(int w, int h)
{
   glViewport(0, 0, w, h);
   glMatrixMode(GL_PROJECTION);
   glLoadIdentity();
   if (w <= (h * 2))
      glOrtho (-6.0, 6.0, -3.0*((GLfloat)h*2)/(GLfloat)w, 
         3.0*((GLfloat)h*2)/(GLfloat)w, -10.0, 10.0);
   else
      glOrtho (-6.0*(GLfloat)w/((GLfloat)h*2), 
         6.0*(GLfloat)w/((GLfloat)h*2), -3.0, 3.0, -10.0, 10.0);
   glMatrixMode(GL_MODELVIEW);
   glLoadIdentity();
}


void mouse(int btn, int state, int x, int y)
{
	if(btn==GLUT_LEFT_BUTTON && state == GLUT_DOWN) 
		drawsphere = ! drawsphere;

	if(btn==GLUT_RIGHT_BUTTON && state == GLUT_DOWN) 
	{
		if (lighton)
			glDisable(GL_LIGHTING);
		else
			glEnable(GL_LIGHTING);
		lighton = !lighton;
	}

	if(btn==GLUT_MIDDLE_BUTTON && state == GLUT_DOWN) 
	{
		if (lighton)
			glDisable(GL_LIGHT0);
		else
			glEnable(GL_LIGHT0);
		lighton = !lighton;
	}
	glutPostRedisplay();
}


int main(int argc, char** argv)
{
   glutInit(&argc, argv);
   glutInitDisplayMode (GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
   glutInitWindowSize (600, 450);
   glutCreateWindow("Some Objects");
   init();
   glutReshapeFunc(reshape);
   glutDisplayFunc(display);
   glutMouseFunc (mouse);
   glutMainLoop();
   return 0; 
}