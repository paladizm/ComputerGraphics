//basic_shadows.cpp
//Illustrates creating hard shadows through projection

//Left mouse click moves the light and a middle mouse click moves it in 
//    the other direction
//Depressing the right mouse with movement moves the sphere up and down
//    Note:  Currently it is possible to move the sphere through the table onto
//           the other side.

#include <GL/glut.h>

int screenWidth = 640, screenHeight = 480;		// Screen size
float sphere_y = 3.0;		// Distance sphere is from ground
float shadow_color[4] = {0.35,0.35,0.35,1};		//Shadows are dark grey
GLfloat light_position[] =  {0.0, 4.0, 0.0, 1.0};	//position of the light
int mouse_lastx, mouse_lasty, dragging = -1;	//Used for mouse functions
float ex=0, ey=7.0, ez=8.0;		// Camera position

// Draw the scene
void drawScene() 
{
	glPushMatrix();
		glTranslatef(0,sphere_y,0);		
		glutSolidSphere(.5, 16, 16);
		glTranslatef(0,-sphere_y,0);
	glPopMatrix();
}

void drawShadow() 
{
	// Set up the shadow-projection matrix
	float shadow_matrix[16];
	int i;
	for (i=0;i<=15;i++) shadow_matrix[i]=0.0;
	shadow_matrix[0] = shadow_matrix[5] = shadow_matrix[10] = 1;
	shadow_matrix[7] = -1/light_position[1];

	// Set the color of the shadow
	glColor3f(shadow_color[0], shadow_color[1], shadow_color[2]);

	// Temporarily disable the depth test and lighting:
	glDisable (GL_DEPTH_TEST);
	glDisable (GL_LIGHTING);

	// Project the object onto the shadow plane
	glPushMatrix();
		glTranslatef(light_position[0], light_position[1], light_position[2]); 
		glMultMatrixf(shadow_matrix); 
		glTranslatef(-light_position[0], -light_position[1], -light_position[2]); 

		// Draw the scene
		drawScene();
	glPopMatrix();

	// Re-enable depth test and lighting:
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_LIGHTING);
}


void myMouse(int button, int state, int mousex, int mousey) 
{
	// Record which button was pressed
	dragging = -1;
	if ((button == GLUT_LEFT_BUTTON) && (state == GLUT_DOWN)) 
	{
		light_position[0] += .1;
		light_position[2] += .1;
		glLightfv(GL_LIGHT0, GL_POSITION, light_position);
		glutPostRedisplay();
	}
	if ((button == GLUT_MIDDLE_BUTTON) && (state == GLUT_DOWN)) 
	{
		light_position[0] -= .1;
		light_position[2] -= .1;
		glLightfv(GL_LIGHT0, GL_POSITION, light_position);
		glutPostRedisplay();
	}
	else if ((button == GLUT_RIGHT_BUTTON) && (state == GLUT_DOWN)) 
	{
		mouse_lastx = mousex;
		mouse_lasty = screenHeight - mousey;
		dragging = GLUT_RIGHT_BUTTON;
	}
}

void myMovedMouse(int mousex, int mousey) 
{
	int x = mousex;
	int y = screenHeight - mousey;
	if (dragging == GLUT_RIGHT_BUTTON) 
	{
		// Move the sphere up or down
		int dy = y - mouse_lasty;
		mouse_lastx = x;
		mouse_lasty = y;
		sphere_y += ((float)dy) / 100.0;
	}
	// Redraw
	glutPostRedisplay();
}

// Setup and turn lighting on
void lights(void)
{
	GLfloat color[] = {.9,.9,.9,1};
	GLfloat acolor[] = {0.7, 0.7, 0.7, 1};
	glShadeModel(GL_SMOOTH);
	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);
	glLightfv(GL_LIGHT0, GL_POSITION, light_position);
	glLightfv(GL_LIGHT0, GL_AMBIENT, acolor);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, color);
	glLightfv(GL_LIGHT0, GL_SPECULAR, color);
}

// Display function;  The floor and light are drawn here since
// we don't want shadows of them.
void myDisplay(void) 
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glEnable(GL_COLOR_MATERIAL);  
	glLoadIdentity();
	// Position the camera
	gluLookAt(ex, ey, ez, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);
	// Position the light in world-space  
	lights();

	// Draw the floor
	glColor3f(0.84,0.66,0.66);
	glBegin(GL_QUADS);
		glNormal3f(0,1,0);
		glVertex3f(-10, 0 , 10);
		glVertex3f( 10, 0 , 10);
		glVertex3f( 10, 0 ,-10);
		glVertex3f(-10, 0 ,-10);
	glEnd();

	// Draws the sphere as a shadow on the floor  
	drawShadow();

	// Draw the scene--the sphere
	drawScene();

	// Draw the light as a little sphere
	glPushMatrix();
		glDisable (GL_LIGHTING);
		glTranslatef(light_position[0],light_position[1],light_position[2]);
		glColor3f(0.8,0.8,0.3);
		glutSolidSphere(0.15,10,10);
		glEnable (GL_LIGHTING);
	glPopMatrix();
	glutSwapBuffers();
}

// Reshape function 
void myReshape(int w, int h) 
{
	screenWidth = w;
	screenHeight = h;
	glViewport(0, 0, screenWidth, screenHeight);  
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(50.0, (GLdouble)screenWidth / (GLdouble)screenHeight, 1.0, 100.);
	glMatrixMode(GL_MODELVIEW);
	glutPostRedisplay();
} 

// Initialization code
void myInit(void) 
{
	glEnable(GL_DEPTH_TEST);
	glClearColor(0.95, 0.95, 0.95, 0.0);
}

// Main function
int main(int argc, char** argv) 
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_DEPTH | GLUT_RGB);
	glutInitWindowSize(screenWidth, screenHeight);
	glutInitWindowPosition(100, 100);
	glutCreateWindow("Simple Hard Shadow");
	glutDisplayFunc(myDisplay);
	glutReshapeFunc(myReshape);
	glutMouseFunc(myMouse);
	glutMotionFunc(myMovedMouse);
	myInit();
	glutMainLoop();
	return 0;
}



