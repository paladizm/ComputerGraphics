//demo of the role of the far & near specification in the glOrtho command
#include <iostream>
#include <iomanip>
using namespace std;
#include <GL/glut.h>

GLdouble Z1, Z2;

void display()
{
    glClear (GL_COLOR_BUFFER_BIT);
	glColor3f (.1176, .565, 1.0);		//Set color to a blue
    glBegin(GL_POLYGON);				
       glVertex3f(25,25,1);
       glVertex3f(-25,25,1);
       glVertex3f(-25,-25,1);
       glVertex3f(25,-25,1);
    glEnd();
    
	glColor3f(1.0, 0.0, 0.0);			//Set Color to red
	glBegin(GL_POLYGON);				
       glVertex3f(100,25,2);
       glVertex3f(100,-25,2);
       glVertex3f(50,-25,2);
       glVertex3f(50,25,2);
    glEnd();

    glFlush();
}

void myinit ()
{
    glClearColor (0.941, 0.973, 1.0, 1.0);
    glShadeModel (GL_FLAT);
	GLdouble left, right, bottom, top, far, near;

	cout << "Objects are in the -25 to 100 range for x \n";
	cout << "                   -25 to  25 range for y\n";
	cout << "                     1 to   2 range for z\n";

	cout << "Please enter the values for left and right: ";
	cin >> left >> right;
	cout << "Please enter the values for bottom and top: ";
	cin >> bottom >> top;
	cout << "Please enter the values for near and far: ";
	cin >> near >> far;

	glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
	glOrtho (left, right, bottom, top, near, far);

	//Dump the projection matrix
	cout << "\nProjection " << endl;
	float m[16];
	glGetFloatv(GL_PROJECTION_MATRIX, m);
	for (int i=0; i<4; i++)
	{
		for (int j=i; j<16; j = j+ 4)
			cout << setw(8) << m[j] << "  ";
		cout << endl;
	}

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity ();
}

int main(int argc, char** argv)
{
    glutInit(&argc,argv);
    glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);
	glutInitWindowSize(700,400); 
	glutInitWindowPosition(300,300);
	glutCreateWindow("Two Polygons");
    myinit();
    glutDisplayFunc(display);
    glutMainLoop();
}
