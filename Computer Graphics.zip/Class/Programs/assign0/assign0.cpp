
//assign0.cpp
//This program is adapted from an example developed by Al Kelley and Ira Pohl

#include "find_root.h"
int cnt = 0;
const dbl eps = 1e-13;

int main (void)
{ 
	dbl a = -10;
	dbl b = 10;
	dbl root;
	assert(f(a)*f(b) <= 0.0);
	root = bisection(f, a, b);
	printf("%s%d\n%s% .15f\n",
		"No. of fct calls: ", cnt,
		"Approximate root: ", root,
		"  Function value: ", f(root));
	return 0;
}

