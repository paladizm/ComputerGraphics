//demo of the role of the far & near specification in the glOrtho command
#include <iostream>
using namespace std;
#include <GL/glut.h>

GLdouble Z1, Z2;

void display()
{
    glClear (GL_COLOR_BUFFER_BIT);
	glColor3f (.1176, .565, 1.0);		//Set color to a blue
    glBegin(GL_POLYGON);				
       glVertex3f(25,25,Z1);
       glVertex3f(-25,25,Z1);
       glVertex3f(-25,-25,Z1);
       glVertex3f(25,-25,Z1);
    glEnd();
    
	glColor3f(1.0, 0.0, 0.0);			//Set Color to red
	glBegin(GL_POLYGON);				
       glVertex3f(100,25,Z2);
       glVertex3f(100,-25,Z2);
       glVertex3f(50,-25,Z2);
       glVertex3f(50,25,Z2);
    glEnd();

    glFlush();
}

void myinit ()
{
    glClearColor (0.941, 0.973, 1.0, 1.0);
    glShadeModel (GL_FLAT);
	GLdouble far, near;

	cout << "Please enter the values for near and far: ";
	cin >> near >> far;

	cout << "Near is set to " << near << " and far is set to " <<
		far << "\n\n";
	cout << "Please enter the z coordinate for the blue polygon ";
	cin >> Z1;
	cout << "Please enter the z coordinate for the red polygon ";
	cin >> Z2;

	glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
	glOrtho (-50.0, 125.0, -50.0, 50.0, near, far);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity ();
}

int main(int argc, char** argv)
{
    glutInit(&argc,argv);
    glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);
	glutInitWindowSize(700,400);    	
	glutCreateWindow("Two Polygons");
    myinit();
    glutDisplayFunc(display);
    glutMainLoop();
}
