#include <GL/glut.h>

float rotX = 0.0, rotY = 0.0;

void Init(void)
{
    float position[] = {0.0, 3.0, 3.0, 0.0};

	//What material is this?
	//float ambient[] = {0.1745, 0.01175, 0.01175};
    //float diffuse[] = {0.61424, 0.04136, 0.04136};
    //float specular[] = {0.727811, 0.626959, 0.626959};

	//What material is this?
    float ambient[] = {0.19125, 0.0735, 0.0225 };
    float diffuse[] = {0.7038, 0.27048, 0.0828 };
    float specular[] = {0.256777, 0.137622, 0.086014 };

    glEnable(GL_DEPTH_TEST);

    glLightfv(GL_LIGHT0, GL_POSITION, position);
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);

    glMaterialfv(GL_FRONT, GL_AMBIENT, ambient);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, diffuse);
    glMaterialfv(GL_FRONT, GL_SPECULAR, specular);

	//Try adjusting the shininess
	glMaterialf(GL_FRONT, GL_SHININESS, 10.0);
    glClearColor(0.9, 0.9, 0.9, 1.0);
}

void Reshape(int w, int h)
{
    glViewport(0, 0, (GLint)w, (GLint)h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(-6.0, 6.0, -6.0, 6.0, -10.0, 10.0);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void SpecialKey(int key, int x, int y)
{
    switch (key) {
		case GLUT_KEY_UP:
			rotX -= 10.0;
			glutPostRedisplay();
			break;
		case GLUT_KEY_DOWN:
			rotX += 10.0;
			glutPostRedisplay();
			break;
		case GLUT_KEY_LEFT:
			rotY -= 10.0;
			glutPostRedisplay();
			break;
		case GLUT_KEY_RIGHT:
			rotY += 10.0;
			glutPostRedisplay();
			break;
    }
}

static void Draw(void)
{
    glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
    glPushMatrix();
		glRotatef(rotY, 0.0,1.0,0.0);
		glRotatef(rotX, 1.0,0.0,0.0);
		glutSolidTeapot(2);

		//Try some different objects
//		glutSolidSphere (3, 10, 10);
//		glutSolidCube (3);
//		glutSolidTorus (1, 2, 20, 20);
    glPopMatrix();
	glutSwapBuffers();
}


int main(int argc, char **argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_RGB | GLUT_DEPTH | GLUT_DOUBLE);
    glutInitWindowSize(400, 400);
    glutCreateWindow("TeaPot");
    Init();
	glutSpecialFunc(SpecialKey);
    glutReshapeFunc(Reshape);
    glutDisplayFunc(Draw);
    glutMainLoop();
}

