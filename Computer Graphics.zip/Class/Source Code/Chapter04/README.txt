This folder contains the following C program for Chapter 4:

cube.c: rotating cube program

cubev.c: rotating cube using vertex arrays

trackball.c: rotating cube using virtual trackball
