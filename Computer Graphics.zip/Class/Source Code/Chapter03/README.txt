This folder contains the following C programs for Chapter 3

square.c: draws a small colored square with each mouse click

single_double.c: displays a rotating cube with both single and double
buffering. Also illustrates use of two independent windows in GLUT.
Note: you may want to insert a timer to slow cube display.

pick.c: Illustrates picking with overlapping red and blue squares

polygon.c: Polygon modeling program

