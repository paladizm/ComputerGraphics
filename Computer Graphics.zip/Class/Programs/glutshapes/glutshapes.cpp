//*************************************************************************
//
//  File Name: GLUT Geometric Primitives 
//  Author   : Ali Baderedine
//  
//  Description: Just a simple program to show GLUT geometric primitives.
//  
//*************************************************************************

#include <gl/glut.h>
#include <math.h>     //  For sqrt
#include <stdarg.h>   //  For variable number of arguments
#include <stdio.h>

// Link the lib files to the program. This is not necessary 
// if you have added the lib names using Project/Settings/Link
#pragma comment (lib, "opengl32.lib")
#pragma comment (lib, "glut32.lib")
#pragma comment (lib, "glu32.lib")

//  Represents the number of shapes
#define SHAPE_COUNT 18

//  define the window position on screen
int window_X_position;
int window_Y_position;

//  variables representing the window size
int window_width = 512;
int window_height = 512;

//  variable representing the window title
char *window_title = "GLUT Geometric Primitives";

//  Tells whether to display the window full screen or not
int fullScreen = 0;

//  Tells whether the shape should be displayed as wireframe or solid
int wireframe = 1;

//  represents the current shape being drawn
int shape = 1;

//  Represents the size of the shape (0.2 --> 1.5)
float shapeSize = 1.25;

//  Color components of the shape
GLubyte R = 100, G = 100, B = 245;

// variables for rotation
float rot_x = 0.0f, rot_y = 0.0f, rot_z = 0.0f;

//  previous mouse position
float previousX, previousY, previousZ;

//  The different Glut shapes
enum GLUT_SHAPES
{
	GLUT_WIRE_CUBE = 0,
	GLUT_SOLID_CUBE,
	GLUT_WIRE_SPHERE,
	GLUT_SOLID_SPHERE,
	GLUT_WIRE_CONE,
	GLUT_SOLID_CONE,
	GLUT_WIRE_TORUS,
	GLUT_SOLID_TORUS,
	GLUT_WIRE_DODECAHEDRON,
	GLUT_SOLID_DODECAHEDRON,
	GLUT_WIRE_OCTAHEDRON,
	GLUT_SOLID_OCTAHEDRON,
	GLUT_WIRE_TETRAHEDRON,
	GLUT_SOLID_TETRAHEDRON,
	GLUT_WIRE_ICOSAHEDRON,
	GLUT_SOLID_ICOSAHEDRON,
	GLUT_WIRE_TEAPOT,
	GLUT_SOLID_TEAPOT
};

void init (void);

//  function that displays shapes on the window
void display (void);

//  function that listens to user's keystrokes
void keyboard (unsigned char key, int x, int y);

// Responds to special Keyboard events
void special (int key, int x, int y);

//  Responds to mouse clicks
void mouse (int, int, int, int);

//  Responds to mouse dragging
void motion (int, int);

//  This function centers your window on the screen
void centerOnScreen (void);

//  Just a pointer to a font style..
//  Fonts supported by GLUT are: GLUT_BITMAP_8_BY_13, 
//  GLUT_BITMAP_9_BY_15, GLUT_BITMAP_TIMES_ROMAN_10, 
//  GLUT_BITMAP_TIMES_ROMAN_24, GLUT_BITMAP_HELVETICA_10,
//  GLUT_BITMAP_HELVETICA_12, and GLUT_BITMAP_HELVETICA_18.
GLvoid *font_style = GLUT_BITMAP_TIMES_ROMAN_24;

//  draws a string (Just as intelligent as printf)
//  If you're new to functions with varaible arguments
//  then check the <stdarg.h> in some C book or
//  type (man stdarg) on Unix terminal. 
void printw(GLfloat x, GLfloat y, char* format, ...);

void init ()
{	
	glClearColor (1.0, 1.0, 1.0, 1.0);
}

void display ()
{
	//  Clear the frame buffer
	glClear (GL_COLOR_BUFFER_BIT);

	//  set the color of the shape
	glColor3ub (R, G, B);

	
	glLoadIdentity ();


	// apply rotation
	glRotatef (rot_x, 1.0f, 0.0f, 0.0f);
	glRotatef (rot_y, 0.0f, 1.0f, 0.0f);
	glRotatef (rot_z, 0.0f, 0.0f, 1.0f);

	switch (shape - wireframe)
	{
		//  draw glut wire cube
		case GLUT_WIRE_CUBE:
			
			glutWireCube (shapeSize/2);
			
			//  Load the identity matrix so that we can clear
			//  the effect of transformations (rotation and scaling)
			glLoadIdentity ();
			
			//  Print object description on screen
			printw (-0.9, -0.9, "Wire Cube");
			
			break;
		//  draw glut solid cube
		case GLUT_SOLID_CUBE:
			
			glutSolidCube (shapeSize/2);

			//  Load the identity matrix so that we can clear
			//  the effect of transformations (rotation and scaling)
			glLoadIdentity ();
			
			//  Print object description on screen
			printw (-0.9, -0.9, "Solid Cube");

			break;
		//  draw glut wire sphere
		case GLUT_WIRE_SPHERE:

			glutWireSphere (shapeSize/2, (GLint)(shapeSize * 10), (GLint)(shapeSize * 10));

			//  Load the identity matrix so that we can clear
			//  the effect of transformations (rotation and scaling)
			glLoadIdentity ();
			
			//  Print object description on screen
			printw (-0.9, -0.9, "Wire Sphere");

			break;
		//  draw glut solid sphere
		case GLUT_SOLID_SPHERE:

			glutSolidSphere (shapeSize/2, (GLint)(shapeSize * 10), (GLint)(shapeSize * 10));

			//  Load the identity matrix so that we can clear
			//  the effect of transformations (rotation and scaling)
			glLoadIdentity ();
			
			//  Print object description on screen
			printw (-0.9, -0.9, "Solid Sphere");

			break;
		//  draw glut wire Cone
		case GLUT_WIRE_CONE:

			glutWireCone (shapeSize/2, shapeSize/2, (GLint)(shapeSize * 10), (GLint)(shapeSize * 10));

			//  Load the identity matrix so that we can clear
			//  the effect of transformations (rotation and scaling)
			glLoadIdentity ();
			
			//  Print object description on screen
			printw (-0.9, -0.9, "Wire Cone");

			break;
		//  draw glut solid cone
		case GLUT_SOLID_CONE:

			glutSolidCone (shapeSize/2, shapeSize/2, (GLint)(shapeSize * 10), (GLint)(shapeSize * 10));

			//  Load the identity matrix so that we can clear
			//  the effect of transformations (rotation and scaling)
			glLoadIdentity ();
			
			//  Print object description on screen
			printw (-0.9, -0.9, "Solid Cone");

			break;
		//  draw glut wire Torus
		case GLUT_WIRE_TORUS:
			
			glutWireTorus (shapeSize/5, shapeSize/2 - shapeSize/5, (GLint)(shapeSize * 20), (GLint)(shapeSize * 20));

			//  Load the identity matrix so that we can clear
			//  the effect of transformations (rotation and scaling)
			glLoadIdentity ();
			
			//  Print object description on screen
			printw (-0.9, -0.9, "Wire Torus");

			break;
		///  draw glut solid Torus
		case GLUT_SOLID_TORUS:

			glutSolidTorus (shapeSize/7, shapeSize/2 - shapeSize/7, (GLint)(shapeSize * 20), (GLint)(shapeSize * 20));

			//  Load the identity matrix so that we can clear
			//  the effect of transformations (rotation and scaling)
			glLoadIdentity ();
			
			//  Print object description on screen
			printw (-0.9, -0.9, "Solid Torus");

			break;
		//  draw a wire dodecahedron.. The reason why I'm dividing
		//  by 2 * radical (3) when I'm scaling is because I want to fit
		//  the dodecahedron which is centered at the modeling 
		//	coordinates origin with a radius of radical (3).
		case GLUT_WIRE_DODECAHEDRON:
			
			glScalef (shapeSize / sqrt (12.), shapeSize / sqrt (12.), shapeSize / sqrt (12.));
			glutWireDodecahedron ();

			//  Load the identity matrix so that we can clear
			//  the effect of transformations (rotation and scaling)
			glLoadIdentity ();
			
			//  Print object description on screen
			printw (-0.9, -0.9, "Wire Dodecahedron");

			break;
		//  draw a solid dodecahedron
		case GLUT_SOLID_DODECAHEDRON:
			glScalef (shapeSize / sqrt (12.), shapeSize / sqrt (12.), shapeSize / sqrt (12.));
			glutSolidDodecahedron ();

			//  Load the identity matrix so that we can clear
			//  the effect of transformations (rotation and scaling)
			glLoadIdentity ();
			
			//  Print object description on screen
			printw (-0.9, -0.9, "Solid Dodecahedron");

			break;
		//  draw a wire octahedron.. The reason why I'm dividing
		//  by 2 when I'm scaling is because I want to fit
		//  the octahedron which is centered at the modeling 
		//	coordinates origin with a radius of 1.
		case GLUT_WIRE_OCTAHEDRON:
			
			glScalef (shapeSize / 2, shapeSize / 2, shapeSize / 2);
			glutWireOctahedron ();

			//  Load the identity matrix so that we can clear
			//  the effect of transformations (rotation and scaling)
			glLoadIdentity ();
			
			//  Print object description on screen
			printw (-0.9, -0.9, "Wire Octahedron");

			break;
		//  draw a solid tetrahedron
		case GLUT_SOLID_OCTAHEDRON:
			glScalef (shapeSize / 2, shapeSize / 2, shapeSize / 2);
			glutSolidOctahedron ();

			//  Load the identity matrix so that we can clear
			//  the effect of transformations (rotation and scaling)
			glLoadIdentity ();
			
			//  Print object description on screen
			printw (-0.9, -0.9, "Solid Octahedron");

			break;
		//  draw a wire tetrahedron.. 
		case GLUT_WIRE_TETRAHEDRON:
			
			glScalef (shapeSize / sqrt(6.), shapeSize / sqrt(6.), shapeSize / sqrt(6.));
			glutWireTetrahedron ();

			//  Load the identity matrix so that we can clear
			//  the effect of transformations (rotation and scaling)
			glLoadIdentity ();
			
			//  Print object description on screen
			printw (-0.9, -0.9, "Wire Tetrahedron");

			break;
		//  draw a solid tetrahedron
		case GLUT_SOLID_TETRAHEDRON:
			glScalef (shapeSize / sqrt(6.), shapeSize / sqrt(6.), shapeSize / sqrt(6.));
			glutSolidTetrahedron ();

			//  Load the identity matrix so that we can clear
			//  the effect of transformations (rotation and scaling)
			glLoadIdentity ();
			
			//  Print object description on screen
			printw (-0.9, -0.9, "Solid Tetrahedron");

			break;
		//  draw a wire icosahedron.. The reason why I'm dividing
		//  by 2 when I'm scaling is because I want to fit
		//  the icosahedron which is centered at the modeling 
		//	coordinates origin with a radius of 1.
		case GLUT_WIRE_ICOSAHEDRON:
			
			glScalef (shapeSize / 2, shapeSize / 2, shapeSize / 2);
			glutWireIcosahedron ();

			//  Load the identity matrix so that we can clear
			//  the effect of transformations (rotation and scaling)
			glLoadIdentity ();
			
			//  Print object description on screen
			printw (-0.9, -0.9, "Wire Icosahedron");

			break;
		//  draw a solid icosahedron
		case GLUT_SOLID_ICOSAHEDRON:
			glScalef (shapeSize / 2, shapeSize / 2, shapeSize / 2);
			glutSolidIcosahedron ();

			//  Load the identity matrix so that we can clear
			//  the effect of transformations (rotation and scaling)
			glLoadIdentity ();
			
			//  Print object description on screen
			printw (-0.9, -0.9, "Solid Icosahedron");

			break;
		//  draw Wire Teapot
		case GLUT_WIRE_TEAPOT:
			
			glutWireTeapot (shapeSize/4);

			//  Load the identity matrix so that we can clear
			//  the effect of transformations (rotation and scaling)
			glLoadIdentity ();
			
			//  Print object description on screen
			printw (-0.9, -0.9, "Wire Teapot");

			break;
		//  draw a solid Teapot
		case GLUT_SOLID_TEAPOT:

			glutSolidTeapot (shapeSize/4);

			//  Load the identity matrix so that we can clear
			//  the effect of transformations (rotation and scaling)
			glLoadIdentity ();
			
			//  Print object description on screen
			printw (-0.9, -0.9, "Solid Teapot");

			break;
		//  Do Nothing
		default:
			break;
	}

	//  Print R, G, B
	printw (0.1, -0.9, "R: %d, G: %d, B: %d", R, G, B);

	glutSwapBuffers ();
}

//  Responds to normal keyboard events
void keyboard (unsigned char key, int x, int y)
{
	switch (key)
	{
		//  User press w (To toggle wireframe)
		case 'w':
		case 'W':
			wireframe = !wireframe;
			break;
		//  Reduce Red color Component
		case 'r':
			R -= 5;

			if (R < 0)
				R = 0;
			break;
		//  Increase red color Component
		case 'R':
			R += 5;

			if (R > 255)
				R = 255;
			break;
		//  Reduce Green color Component
		case 'g':
			G -= 5;

			if (G < 0)
				G = 0;
			break;
		//  Increase green color Component
		case 'G':
			G += 5;

			if (G > 255)
				G = 255;
			break;
		//  Reduce blue color Component
		case 'b':
			B -= 5;

			if (B < 0)
				B = 0;
			break;
		//  Increase blue color Component
		case 'B':
			B += 5;

			if (B > 255)
				B = 255;
			break;
			
		//  User press Escape (to Exit)
		case 27:
			exit (0);
			break;
	}

	//  Call the display function
	glutPostRedisplay ();
}

// Responds to special Keyboard events
void special (int key, int x, int y)
{
	//  To Chage Shape
	if (key == GLUT_KEY_LEFT)
	{
		shape -= 2;

		if (shape < 1)
			shape = SHAPE_COUNT - 1;
	}
	else if (key == GLUT_KEY_RIGHT)
	{
		shape += 2;

		if (shape > SHAPE_COUNT - 1)
			shape = 1;
	}

	//  to Chage Size
	else if (key == GLUT_KEY_UP)
	{
		shapeSize += 0.05;

		if (shapeSize > 1.5)
			shapeSize = 1.5;
	}
	else if (key == GLUT_KEY_DOWN)
	{
		shapeSize -= 0.05;

		if (shapeSize < 0.2)
			shapeSize = 0.2;
	}

	//  Call the display function
	glutPostRedisplay ();
}

// Listens to mouse clicks
void mouse (int button, int state, int x, int y) 
{	
	// reset the previousX, previousY, and previousZ to the current position of the mouse
	previousX = x;
	previousY = y;
	previousZ = y;
}

// function used when the user is moving the mouse
void motion (int x, int y) 
{	
	//  Rotate
	rot_x += (y - previousY);
	rot_y += (x - previousX);

	// reset the previousX, previousY, and previousZ to the current position of the mouse
	previousX = (float)x;
	previousY = (float)y;
	previousZ = (float)y;

	//  Call the display function
	glutPostRedisplay ();
}

//  Print text on the screen
void printw (float x, float y, char* format, ...)
{
    va_list arg_list;
    char str[256];
	int i;
    
    va_start(arg_list, format);
    vsprintf(str, format, arg_list);
    va_end(arg_list);
    
    glRasterPos2f (x, y);

    for (i = 0; str[i] != '\0'; i++)
        glutBitmapCharacter(font_style, str[i]);
}

void centerOnScreen (void)
{
	//  Set the window position such that the window becomes centered
	window_X_position = (glutGet (GLUT_SCREEN_WIDTH) - window_width)/2;
	window_Y_position = (glutGet (GLUT_SCREEN_HEIGHT) - window_height)/2;
}

void main (int argc, char **argv)
{
	centerOnScreen ();

	glutInit(&argc, argv);
	glutInitWindowSize (window_width, window_height);
	glutInitWindowPosition (window_X_position, window_Y_position);
	glutInitDisplayMode (GLUT_RGB | GLUT_DOUBLE);
	glutCreateWindow (window_title);
	
	//  Initialize stuff that remain constant throughout the
	//  program.
	init();

	if (fullScreen)
		glutFullScreen ();
	
	// Set the display function
	glutDisplayFunc (display);

	//  Set the keyboard function
	glutKeyboardFunc (keyboard);

	//  Set the special func
	glutSpecialFunc (special);

	//  Set mouse function
	glutMouseFunc (mouse);

	// Set mouse motion function
	glutMotionFunc (motion);

	glutMainLoop();
}

