//fct.cpp
#include "find_root.h"

dbl f(dbl x)
{
	return (x*x*x*x*x - 7.0*x -3.0);
}