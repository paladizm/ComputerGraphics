//reflection.cpp
//Inplement reflection through rotation 
#include <iostream>
#include <iomanip>
#include <GL/glut.h>
using namespace std;

char choice;
void mydisplay() 
{
	float m[16];
	glClear(GL_COLOR_BUFFER_BIT);
	glBegin(GL_LINES); 
		glColor3f(1.0, 1.0, 0.0); 
		glVertex2f(-100, 0); 
		glVertex2f(100, 0); 
		glVertex2f(0, -100); 
		glVertex2f(0, 100); 
	glEnd();	
	if (choice == '2')
	{
		glRotatef(180, 0.0, 1.0, 0.0);
	}
	else if (choice == '3')
	{
		glRotatef(180, 0.0, 1.0, 0.0);
		glRotatef(180, 1.0, 0.0, 0.0);
	}
	else if (choice == '4')
	{
		glRotatef(180, 1.0, 0.0, 0.0);
	}
	cout << "\nModelview after Rotation " << endl;
	glGetFloatv(GL_MODELVIEW_MATRIX, m);
	for (int i=0; i<4; i++)
	{
		for (int j=i; j<16; j = j+ 4)
			cout << setw(8) << m[j] << "  ";
		cout << endl;
	}

	glBegin(GL_POLYGON); 
		glColor3f(1.0, 0.0, 0.0); 
		glVertex2f(50.0, 87.5); 
		glColor3f(0.0, 1.0, 0.0); 
		glVertex2f(25.0, 62.5); 
		glColor3f(0.0, 0.0, 1.0); 
		glVertex2f(25.0, 25.0); 
		glColor3f(1.0, 1.0, 1.0); 
		glVertex2f(75.0, 25.0); 
		glColor3f(0.0, 1.0, 1.0); 
		glVertex2f(75.0, 62.5); 
	glEnd();
	glLoadIdentity();						

	glBegin(GL_POLYGON); 
		glColor3f(1.0, 0.0, 0.0); 
		glVertex2f(50.0, 87.5); 
		glColor3f(0.0, 1.0, 0.0); 
		glVertex2f(25.0, 62.5); 
		glColor3f(0.0, 0.0, 1.0); 
		glVertex2f(25.0, 25.0); 
		glColor3f(1.0, 1.0, 1.0); 
		glVertex2f(75.0, 25.0); 
		glColor3f(0.0, 1.0, 1.0); 
		glVertex2f(75.0, 62.5); 
	glEnd();
	glFlush();
}


void init()
{
	cout.setf(ios::fixed);
	cout.setf(ios::showpoint);
	cout.precision(2);
	glClearColor (0.0, 0.0, 0.0, 1.0);
	glLineWidth(3);
	glMatrixMode (GL_PROJECTION);    
	glLoadIdentity ();    
	glOrtho(-100, 100, -100, 100, 0, 100);  
	glMatrixMode (GL_MODELVIEW);    
	glLoadIdentity();						
	cout << "Display original (1) or reflect into quadrant 2, 3, or 4? ";
	cin >> choice;

}


int main(int argc, char** argv)
{
	glutInit(&argc,argv); 
	glutInitDisplayMode(GLUT_SINGLE|GLUT_RGB);      
	glutInitWindowSize(600,600);    	
	glutInitWindowPosition(0,0); 
	glPolygonMode (GL_FRONT, GL_FILL);
	glPolygonMode (GL_BACK, GL_LINE);
	glutCreateWindow("Reflection w Rotation");     
	glutDisplayFunc(mydisplay);  
	init(); 
	glutMainLoop();
}
