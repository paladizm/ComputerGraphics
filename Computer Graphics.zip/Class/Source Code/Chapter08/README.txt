This directory has the following C programs for Chapter 8:

bres.c: draws a line segment using Bresenham's algorithm and a
virtual frame buffer

mandebrot.c: displays a mandelebrot set. 

tex_cube.c: rotating cube with a checkboard texture.
