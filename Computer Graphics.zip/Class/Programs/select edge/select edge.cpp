#include <cstdlib>
#include <iostream>
#include <cmath>
#include <GL/glut.h>
using namespace std;

void mouse(int, int, int, int);
void key(unsigned char, int, int);
void display();
void drawGrid();
void myReshape(GLsizei, GLsizei);
bool takeSquare(int H, int V, int xdot, int ydot, int player);
void myinit();

int dot[10][10][2];		//Key data structure
int ndots;
int psquares[3] = {0,0,0};
GLfloat color[3][3];
int player = 1;
int square[9][9];

GLsizei wh = 700, ww = 700; /* window size */
int slength = 60;		//length of a section between dots
int dx = 80;			//distance around the border
int dy = 80;

void drawGrid()
{
	int i, j;
    glColor3f(0, 1.0, 0);

	//Draw the grid with sections in very light gray if not selected and in
	//appropriate color otherwise.
	for (i=0; i < ndots; i++)
		for (j=0; j<ndots; j++)
		{
			if (dot[i][j][0] != -1)
			{
				//Draw line up
				glColor3fv(color[dot[i][j][0]]);
				glBegin(GL_LINES);
					glVertex2f(dx+i*slength, dy+j*slength);
					glVertex2f(dx+i*slength, dy+(j+1)*slength);
				glEnd();
			}
			if (dot[i][j][1] != -1)
			{
				glColor3fv(color[dot[i][j][1]]);
				//Draw line right
				glBegin(GL_LINES);
					glVertex2f(dx+i*slength, dy+j*slength);
					glVertex2f(dx+(i+1)*slength, dy+j*slength);
				glEnd();
			}
		}
	//Draw dots
	glColor3f(0,0,0);
	glBegin(GL_POINTS);
		for (i = 0; i < ndots; i++)
		{
			for (j=0; j < ndots; j++)
			{
				glVertex2f(dx+i*slength, dy+j*slength);
			}
		}
	glEnd();
	////Draw Squares
	//for (i=0; i<ndots; i++)
	//{
	//	for (j=0; j<ndots; j++)
	//	{
	//		int c;
	//		int size = 10;
	//		c = square[i][j];
	//		if (c)
	//		{
	//			if (c==1)
	//				glColor3f(1,0,0);
	//			else
	//				glColor3f(0,0,1);
	//			int x = 110+i*slength;
	//			int y = 110 + j*slength;
	//	      glBegin(GL_POLYGON);
	//		      glVertex2f(x+size, y+size);
	//		      glVertex2f(x-size, y+size);
	//		      glVertex2f(x-size, y-size);
	//			  glVertex2f(x+size, y-size);
	//		  glEnd();

	//		}
	//	}
	//}
}


/* reshaping routine called whenever window is resized or moved */
void myReshape(GLsizei w, GLsizei h)
{
	glutReshapeWindow(wh, ww);		//keep the window size the same
}

void myinit()
{
	int i, j;
	do
	{
		cout << "What size grid of dots would you like to create? ";
		cin >> ndots;
	} while (ndots <= 3 || ndots > 10);
	
	wh = ww = 160+(ndots-1)*slength;	//calculate the height and width
	glViewport(0,0,ww,wh);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0.0, (GLdouble) ww , 0.0, (GLdouble) wh , -1.0, 1.0);
    glClearColor (1, 1, 1, 1.0);
    glClear(GL_COLOR_BUFFER_BIT);
    glutSwapBuffers();

	//edge colors
	color[0][0] = 0.95;		//Light gray for not seleted
	color[0][1] = 0.95;
	color[0][2] = 0.95;
	color[1][0] = 1.0;		//Red
	color[1][1] = 0.0;
	color[1][2] = 0.0;
	color[2][0] = 0.0;		//Blue
	color[2][1] = 0.0;
	color[2][2] = 1.0;

	//Initialize the underlying data structures.  3rd sub of 0 is up
	//3rd sub of 1 means right
	//0 means legal and not connected, -1 means illegal
	//1 means drawn by player 1, 2 means drawn by player 2
	for (i=0; i<ndots; i++)
	{
		for (j=0; j<ndots; j++)
		{
			square[i][j]=0;
			if (j+1 < ndots)
				dot[i][j][0] = 0;
			else
				dot[i][j][0] = -1;
			if (i+1 < ndots)
				dot[i][j][1] = 0;
			else
				dot[i][j][1] = -1;
		}
	}
	psquares[0]=(ndots-1)*(ndots-1);	//set number of open squares
	player = 1;
	glLineWidth(3);
	glPointSize(5);
}


void display()
{
    glClear(GL_COLOR_BUFFER_BIT);
	drawGrid();
    glutSwapBuffers();
}

void mouse(int btn, int state, int x, int y) 
{
	int xdot, ydot;
	y = wh - y;
    if(btn==GLUT_RIGHT_BUTTON && state==GLUT_DOWN)   
		exit(0);
	else if(btn==GLUT_LEFT_BUTTON && state==GLUT_DOWN) 
	{
		int vertical = -1, horizontal = -1, i;
		if (x>=dx-5 && x <= dx+(ndots-1)*slength+5 
			&& y>=dy-5 && y <= dy+(ndots-1)*slength+5)
		{
			for (i=0; i <= ndots && vertical == -1; i++)
			{
				//Find out if a vertical edge
				if (abs(x-(dx+i*slength)) <= 10)
					vertical = i;
			}
			for (i=0; i <= ndots && horizontal == -1; i++)
			{
				//Find out if a vertical edge
				if (abs(y-(dy+i*slength)) <= 10)
					horizontal = i;
			}
			if ((horizontal==-1 && vertical != -1) || 
				(horizontal != -1 && vertical == -1))
			{
				if (vertical != -1)
				{
					xdot=vertical;
					ydot = (y-dy)/slength;
				}
				else
				{
					ydot=horizontal;
					xdot = (x-dx)/slength;
				}
				if (horizontal != -1 && dot[xdot][ydot][1] == 0)
				{
					dot[xdot][ydot][1] = player;
					player = player % 2 + 1;
				}
				else if (dot[xdot][ydot][0] == 0)
				{
					dot[xdot][ydot][0] = player;
					player = player % 2 + 1;
				}
				//Here, call a function to see if a square has been taken
			}
		}
	}
	glutPostRedisplay();
}

bool takeSquare(int H, int V, int xdot, int ydot, int player)
{
	bool result = false;
	return result;
}

int main(int argc, char** argv)
{
    glutInit(&argc,argv);
    glutInitDisplayMode (GLUT_DOUBLE | GLUT_RGB);
	glutInitWindowSize(ww,wh);    	
    glutCreateWindow("your name - Dots");
    glutDisplayFunc(display);
    myinit();
    glutReshapeFunc (myReshape);
    glutMouseFunc (mouse);
    glutMainLoop();
}
