/*  scenematerial.cpp
*  This program demonstrates the drawing of a shaded scene
*  constructed with various modeling transformations.
*  Click the right button to exit.
*/

// Original scene from the book Computer Graphics Using OpenGL by Hill & Kelley
#include <iostream>
#include <cmath>
#include <GL/glut.h>

//<<<<<<<<<<<<<<<<<<< wall >>>>>>>>>>>>>>
void wall(double thickness)
{ // draw thin wall with top =xz-plane, corner at origin 
	glPushMatrix();
	glTranslated(0.5, 0.5*thickness, 0.5); 
	glScaled(1.0, thickness, 1.0);
	glutSolidCube(1.0);
	glPopMatrix();
}

//<<<<<<<<<<<<<<<<<<< tableleg >>>>>>>>>>>>>>
void tableLeg(double thick, double len)
{ // draw a table leg with dimension: thick x len x thick 
	glPushMatrix();
	glTranslated(0, len/2, 0); 
	glScaled(thick, len, thick );
	glutSolidCube(1.0);
	glPopMatrix();
}

//<<<<<<<<<<<<<<<<<<< jack part >>>>>>>>>>>>>>
void jackpart()
{ // draw one axis of the unit jack - a stretched sphere
	glPushMatrix();
	glScaled(0.2, 0.2, 1.0);
	glutSolidSphere(1, 15, 15);
	glPopMatrix();
	//
	glPushMatrix();
	glTranslated(0, 0, 1.2); 
	glutSolidSphere(0.2, 15, 15);  // ball on one end
	glTranslated(0, 0, -2.4); 
	glutSolidSphere(0.2, 15, 15);  // ball on the other end
	glPopMatrix();
}

//<<<<<<<<<<<<<<<<<<< jack >>>>>>>>>>>>>>
void jack()
{ // draw a unit jack out of spheroids 
	glPushMatrix();
	jackpart();
	glRotated(90.0, 0, 1, 0);
	jackpart();
	glRotated(90.0, 1, 0, 0);
	jackpart();
	glPopMatrix();
}

//<<<<<<<<<<<<<<<<<<< table >>>>>>>>>>>>>>
void table(double topWid, double topThick, double legThick, double legLen)
{ // draw the table - a top and four legs 
	glPushMatrix();
	glTranslated(0, legLen, 0); 
	glScaled(topWid, topThick, topWid);
	glutSolidCube(1.0);            // draw the table top
	glPopMatrix();
	//
	double dist = 0.95 * topWid/2.0 - legThick/2.0;
	glPushMatrix();
	glTranslated(dist, 0, dist); 
	tableLeg(legThick, legLen);
	glTranslated(0, 0, -2 * dist); 
	tableLeg(legThick, legLen);
	glTranslated(-2 * dist, 0, 2 * dist); 
	tableLeg(legThick, legLen);
	glTranslated(0, 0, -2 * dist); 
	tableLeg(legThick, legLen);
	glPopMatrix();
}

//<<<<<<<<<<<<<<<<<<<<<<<<<<<<< displaySolid >>>>>>>>>>>>>>>>>>>>>>
void displaySolid(void)
{
	// set the light source properties
	GLfloat light_position [] = {2.0f, 6.0f, 3.0f, 0.0f};
    glLightfv(GL_LIGHT0, GL_POSITION, light_position);

	// set the camera
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	double winHt = 1.0;  //half-height of the window
	glOrtho(-winHt*64/48.0, winHt*64/48.0, -winHt, winHt, 0.1, 100.0);
	glMatrixMode(GL_MODELVIEW);      // position and aim the camera
	glLoadIdentity();
	gluLookAt(2.3, 1.3, 2.0, 0.0, 0.25, 0.0, 0.0, 1.0, 0.0);

	// start drawing
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT); // clear the screen
	glPushMatrix(); 
		glTranslated(0.4, 0.4, 0.6);
		glRotated(45, 0, 0, 1); 
		glScaled(0.08, 0.08, 0.08);
		
		GLfloat jack_mat_ambient[] = {0.0215, 0.1745, 0.0215};
		GLfloat jack_mat_diffuse[] = {0.07568, 0.61424, 0.07568};
		GLfloat jack_mat_specular[] = {0.633, 0.727811, 0.633}; 
		GLfloat jack_mat_shininess [] = {50.0f};
		glMaterialfv(GL_FRONT, GL_AMBIENT, jack_mat_ambient);
		glMaterialfv(GL_FRONT, GL_DIFFUSE, jack_mat_diffuse);
		glMaterialfv(GL_FRONT, GL_SPECULAR, jack_mat_specular);
		glMaterialfv(GL_FRONT, GL_SHININESS, jack_mat_shininess);
		jack();  // draw the jack
	glPopMatrix();
	//
	glPushMatrix(); 
		glTranslated(0.6, 0.38, 0.5);
		glRotated(30, 0, 1, 0);
	    GLfloat tea_mat_ambient[] = {0.19125, 0.0735, 0.0225 };
		GLfloat tea_mat_diffuse[] = {0.7038, 0.27048, 0.0828 };
		GLfloat tea_mat_specular[] = {0.256777, 0.137622, 0.086014};
		GLfloat tea_mat_shininess [] = {100.0f};
		glMaterialfv(GL_FRONT, GL_AMBIENT, tea_mat_ambient);
		glMaterialfv(GL_FRONT, GL_DIFFUSE, tea_mat_diffuse);
		glMaterialfv(GL_FRONT, GL_SPECULAR, tea_mat_specular);
		glMaterialfv(GL_FRONT, GL_SHININESS, tea_mat_shininess);
		glutSolidTeapot( 0.08);  // draw the teapot
		glPopMatrix();
	//
	
	glPushMatrix(); 
		glTranslated(0.25, 0.42, 0.35);
		GLfloat ball_mat_ambient[] = {0.1745, 0.01175, 0.01175};
		GLfloat ball_mat_diffuse[] = {0.61424, 0.04136, 0.04136};
	    GLfloat ball_mat_specular[] = {0.727811, 0.626959, 0.626959};
		GLfloat ball_mat_shininess [] = {80.0f};
		glMaterialfv(GL_FRONT, GL_AMBIENT, ball_mat_ambient);
		glMaterialfv(GL_FRONT, GL_DIFFUSE, ball_mat_diffuse);
		glMaterialfv(GL_FRONT, GL_SPECULAR, ball_mat_specular);
		glMaterialfv(GL_FRONT, GL_SHININESS, ball_mat_shininess);
		glutSolidSphere( 0.1, 15, 15);  // draw the sphere
	glPopMatrix();


	//
	glPushMatrix(); 
		glTranslated(0.4, 0, 0.4);
		// set properties of the surface material for the table
		GLfloat table_mat_ambient [] = {0,0,0};
		GLfloat table_mat_diffuse [] = {.5,.5,0};
		GLfloat table_mat_specular [] = {.6,.6,.5};
		GLfloat table_mat_shininess [] = {32};
		
		glMaterialfv(GL_FRONT, GL_AMBIENT, table_mat_ambient);
		glMaterialfv(GL_FRONT, GL_DIFFUSE, table_mat_diffuse);
		glMaterialfv(GL_FRONT, GL_SPECULAR, table_mat_specular);
		glMaterialfv(GL_FRONT, GL_SHININESS, table_mat_shininess);

		table(0.6, 0.02, 0.02, 0.3);  // draw the table
	glPopMatrix();
	
		// set properties of the surface material for the wall
	glPushMatrix();
		//Cyan
		GLfloat wall_mat_ambient [] = {.19225,.19225,.19225};
		GLfloat wall_mat_diffuse [] = {.50754,.50754,.50754};
		GLfloat wall_mat_specular [] = {.508273,508273,508273};
		GLfloat wall_mat_shininess [] = {50};
		
		glMaterialfv(GL_FRONT, GL_AMBIENT, wall_mat_ambient);
		glMaterialfv(GL_FRONT, GL_DIFFUSE, wall_mat_diffuse);
		glMaterialfv(GL_FRONT, GL_SPECULAR, wall_mat_specular);
		glMaterialfv(GL_FRONT, GL_SHININESS, wall_mat_shininess);

		wall(0.02);  // wall no 1: in xz-plane
	glPopMatrix();
	//
	glPushMatrix(); 
		glRotated(90.0, 0.0, 0.0, 1.0);
		wall(0.02);
	glPopMatrix();
	//
	glPushMatrix(); 
		glRotated(-90.0, 1.0, 0.0, 0.0);
		wall(0.02);
	glPopMatrix();
	//
	glFlush();
}

void myMouse(int button, int state, int x, int y)
{
	switch (button) {
	 case GLUT_RIGHT_BUTTON:
		 if (state == GLUT_DOWN)
			 exit (-1);
		 break;
	 default:
		 break;
	}
}

void reshape(int w, int h)
{
    glutReshapeWindow(640,480);
}

void init()
{
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_NORMALIZE);		//run without this to see effect
	glClearColor(0.1f, 0.1f, 0.1f,0.0f);  

	// set the camera
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	double winHt = 1.0;  //half-height of the window
	glOrtho(-winHt*64/48.0, winHt*64/48.0, -winHt, winHt, 0.1, 100.0);
	glMatrixMode(GL_MODELVIEW);      // position and aim the camera
	glLoadIdentity();
	gluLookAt(2.3, 1.3, 2.0, 0.0, 0.25, 0.0, 0.0, 1.0, 0.0);

}

//<<<<<<<<<<<<<<<<<<<<<< main >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
int main(int argc, char **argv)
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB | GLUT_DEPTH );
	glutInitWindowSize(640,480);
	glutInitWindowPosition(100, 100);
	glutCreateWindow("Shaded example - 3D scene");
	glutDisplayFunc(displaySolid);
	glEnable(GL_LIGHTING);		//Remove the comment on this first
	glEnable(GL_LIGHT0);		//Remove the comment on this second
	glLightModeli(GL_LIGHT_MODEL_LOCAL_VIEWER, GL_TRUE);
	glColor3f(1.0,0.0,0.0);		//Remove the comment on this third
	glShadeModel(GL_SMOOTH);
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_NORMALIZE);
	glClearColor(0.1f, 0.1f, 0.1f,0.0f);  // background is light gray
	glViewport(0, 0, 640, 480);
	glutMainLoop();
}

