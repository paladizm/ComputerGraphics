//reshape.cpp

#include <GL/glut.h>

int w0, w1, w2, w3, w4, w5;

void mydisplay()
{
	glClear(GL_COLOR_BUFFER_BIT); 
	glColor3f(1.0, 0.0, 0.0); 
	glBegin(GL_POLYGON); 
		glVertex2f(-0.5, -0.5);        
		glVertex2f(-0.5, 0.5);        
		glVertex2f(0.5, 0.5);        
		glVertex2f(0.5, -0.5);
	glEnd();
	glColor3f(0.0, 1.0, 0.0); 
	glBegin(GL_POLYGON);
		glVertex2f(-1.5, 0.0);        
		glVertex2f(-1.5, .25);        
		glVertex2f(-1.25, .25);        
		glVertex2f(-1.25, 0.0);    
	glEnd();
	glFlush(); 
}
void reshape1(int w, int h)
{
    glViewport(0, 0, w, h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    if (w <= h)
		glOrtho (-1.0, 1.0, -1.0*(GLfloat)h/(GLfloat)w,
			1.0*(GLfloat)h/(GLfloat)w, -1.0, 1.0);
    else
		glOrtho (-1.0*(GLfloat)w/(GLfloat)h,
			1.0*(GLfloat)w/(GLfloat)h, -1.0, 1.0, -1.0, 1.0);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity ();
}

void reshape2(int w, int h)
{
  
}

void reshape3(int w, int h)
{
    glViewport(0, 0, w, h);
}

void reshape4(int w, int h)
{
    glutReshapeWindow(400,400);
}


void init()
{
	glClearColor (.9, .9, 1.0, 1.0);
	glMatrixMode (GL_PROJECTION);    
	glLoadIdentity ();    
	glOrtho(-1.0, 1.0, -1.0, 1.0, -1.0, 1.0);  
}


int main(int argc, char** argv)
{

	glutInit(&argc,argv); 
	glutInitDisplayMode(GLUT_SINGLE|GLUT_RGB);      
	glutInitWindowSize(400,400);    	
	glutInitWindowPosition(0,0); 
	w1 = glutCreateWindow("Shape (Aspect Ratio) Preserving");  
	glutReshapeFunc(reshape1);
	glutDisplayFunc(mydisplay);  
	init(); 

	glutInitDisplayMode(GLUT_SINGLE|GLUT_RGB);      
	glutInitWindowSize(400,400);    	
	glutInitWindowPosition(30,30); 
	w0 = glutCreateWindow("Default Reshape");  
	glutDisplayFunc(mydisplay);  
	init(); 

	glutInitDisplayMode(GLUT_SINGLE|GLUT_RGB);      
	glutInitWindowSize(400,400);    	
	glutInitWindowPosition(60,60); 
	w2 = glutCreateWindow("Empty Reshape");  
	glutReshapeFunc(reshape2);
	glutDisplayFunc(mydisplay);  
	init(); 

	glutInitDisplayMode(GLUT_SINGLE|GLUT_RGB);      
	glutInitWindowSize(400,400);    	
	glutInitWindowPosition(90,90); 
	w3 = glutCreateWindow("Viewport Changed to New w, h");  
	glutReshapeFunc(reshape3);
	glutDisplayFunc(mydisplay);  
	init(); 

	glutInitDisplayMode(GLUT_SINGLE|GLUT_RGB);      
	glutInitWindowSize(400,400);    	
	glutInitWindowPosition(120,120); 
	w4 = glutCreateWindow("Reshape Blocked");  
	glutReshapeFunc(reshape4);
	glutDisplayFunc(mydisplay);  
	init(); 

	glutMainLoop();
}
