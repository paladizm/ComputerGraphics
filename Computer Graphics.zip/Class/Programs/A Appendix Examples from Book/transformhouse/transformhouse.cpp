//transformhouse.cpp
#include <iostream>
#include <GL/glut.h>
using namespace std;
GLdouble p1[3] = {50, 87.5, 0};
GLdouble p2[3] = {25.0, 62.5, 0}; 
GLdouble p3[3] = {75.0, 62.5, 0}; 
GLdouble p4[3] = {25.0, 25.0, 0}; 
GLdouble p5[3] = {75.0, 25.0, 0}; 

int click = 0;

void mouse(int btn, int state, int x, int y) 
{
    if(btn==GLUT_RIGHT_BUTTON && state==GLUT_DOWN)   
		exit(0);
	else if (btn==GLUT_LEFT_BUTTON && state==GLUT_DOWN && click%2 == 0)
	{
		//Clear the tranformation matrix
		glLoadIdentity();

		//Translate
		glTranslated(50, 50, 0);

		//Rotate
		glRotated(45,0,0,1);
			
		//scale
		glScaled(.6, .6, 1);

		//translate
		glTranslated(-25, -25, 0);
		click++;
	}
	else if (btn==GLUT_LEFT_BUTTON && state==GLUT_DOWN && click%2 == 1)
	{
		//What happens if we uncomment the following line and why?
		//glLoadIdentity();

		//Translate
		glTranslated(25, 25, 0);

		//Rotate
		glRotated(-45,0,0,1);
			
		//scale
		glScaled(1/.6, 1/.6, 1);

		//translate
		glTranslated(-50, -50, 0);
		click++;
	}
	glutPostRedisplay();
}

void mydisplay() 
{
	glClear(GL_COLOR_BUFFER_BIT);
	glColor3f(1.0, 0.0, 0.0); 
	glBegin(GL_TRIANGLE_STRIP); // draw in triangle strips
		glVertex3dv(p1);
		glVertex3dv(p2);
		glVertex3dv(p3);
		glVertex3dv(p4);
		glVertex3dv(p5);
	glEnd();
    glFlush();
}

void init()
{
	glClearColor (1.0, 1.0, 1.0, 1.0);
	glColor3f(1.0, 1.0, 1.0); 

	//Go into projection mode long enough to set the projection
	glMatrixMode (GL_PROJECTION);    
	glLoadIdentity ();    
	glOrtho(0, 100, 0, 100, 0, 100);

	//Go back into modelview mode
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
}


int main(int argc, char** argv)
{
	glutInit(&argc,argv); 
	glutInitDisplayMode(GLUT_SINGLE|GLUT_RGB);      
	glutInitWindowSize(500,500);    	
	glutInitWindowPosition(0,0); 
	glutCreateWindow("Red House");     
	glutDisplayFunc(mydisplay); 
	glutMouseFunc (mouse);
 	init(); 
	glutMainLoop();
}
