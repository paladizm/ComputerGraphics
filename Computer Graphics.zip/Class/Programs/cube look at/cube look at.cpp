//house.cpp
#include <iostream>
#include <GL/glut.h>
using namespace std;

int view = -1;
int ww, wh;

void setview();

void mouse(int btn, int state, int x, int y) 
{
    if(btn==GLUT_RIGHT_BUTTON && state==GLUT_DOWN)   
		exit(0);
	else if (btn==GLUT_LEFT_BUTTON && state==GLUT_DOWN)
		setview();
	glutPostRedisplay();
}

void setview()
{	
	view = (view+1) % 8;
	glLoadIdentity();
	if (view == 0)
		gluLookAt(-.5, -.5, -.5,    0.0, 0.0, 0.0,    0.0, 1.0, 0.0);	//0 0 0
	else if (view == 1)
	{ }
	else if (view == 2)
	{ }
	else if (view == 3)
	{ }
	else if (view == 4)
	{ }
	else if (view == 5)
	{ }
	else if (view == 6)
	{ }
	else
	{ }
}

void myReshape(int w, int h) 
{
	glutReshapeWindow(500, 500);
}

void mydisplay() 
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glBegin(GL_POLYGON); //face in the y = 1 plane
		glColor3f(0.0, 1.0, 1.0); 
		glVertex3f(0,1,1);
		glColor3f(0.0, 1.0, 0.0); 
		glVertex3f(0,1,0);
		glColor3f(1.0, 1.0, 0.0); 
		glVertex3f(1,1,0);
		glColor3f(1.0, 1.0, 1.0); 
		glVertex3f(1,1,1);
	glEnd();

	glBegin(GL_POLYGON); //face in the z = 1 plane
		glColor3f(0.0, 0.0, 1.0); 
		glVertex3f(0,0,1);
		glColor3f(0.0, 1.0, 1.0); 
		glVertex3f(0,1,1);
		glColor3f(1.0, 1.0, 1.0); 
		glVertex3f(1,1,1);
		glColor3f(1.0, 0.0, 1.0); 
		glVertex3f(1,0,1);
 	glEnd();

	glBegin(GL_POLYGON); //face in the x = 1 plane
		glColor3f(1.0, 1.0, 1.0); 
		glVertex3f(1,1,1);
		glColor3f(1.0, 1.0, 0.0); 
		glVertex3f(1,1,0);
		glColor3f(1.0, 0.0, 0.0); 
		glVertex3f(1,0,0);
		glColor3f(1.0, 0.0, 1.0); 
		glVertex3f(1,0,1);
 	glEnd();

	glBegin(GL_POLYGON);	//face in the z = 0 plane
		glColor3f(0.0, 0.0, 0.0); 
		glVertex3f(0,0,0);
		glColor3f(1.0, 0.0, 0.0); 
		glVertex3f(1,0,0);
		glColor3f(1.0, 1.0, 0.0); 
		glVertex3f(1,1,0);
		glColor3f(0.0, 1.0, 0.0); 
		glVertex3f(0,1,0);
	glEnd();

	glBegin(GL_POLYGON);	//face in the y = 0 plane 
		glColor3f(1.0, 0.0, 1.0); 
		glVertex3f(1,0,1);
		glColor3f(1.0, 0.0, 0.0); 
		glVertex3f(1,0,0);
		glColor3f(0.0, 0.0, 0.0); 
		glVertex3f(0,0,0);
		glColor3f(0.0, 0.0, 1.0); 
		glVertex3f(0,0,1);
	glEnd();

	glBegin(GL_POLYGON);	//face in the x = 0 plane 
		glColor3f(0.0, 1.0, 0.0); 
		glVertex3f(0,1,0);
		glColor3f(0.0, 1.0, 1.0); 
		glVertex3f(0,1,1);
		glColor3f(0.0, 0.0, 1.0); 
		glVertex3f(0,0,1);
		glColor3f(0.0, 0.0, 0.0); 
		glVertex3f(0,0,0);
	glEnd();

   glutSwapBuffers();
}
void init()
{
	glClearColor (0.0, 0.0, 0.0, 1.0);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
    glOrtho(-2, 2, -2, 2, -2, 2);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
}


int main(int argc, char** argv)
{
	glutInit(&argc,argv); 
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);   
	glPolygonMode(GL_FRONT, GL_FILL);
	glPolygonMode(GL_BACK, GL_LINE);
	glutInitWindowSize(500,500);    	
	glutInitWindowPosition(0,0);
	glutCreateWindow("Color Cube");
	glEnable(GL_DEPTH_TEST); 
	glutDisplayFunc(mydisplay);  
    glutReshapeFunc (myReshape);
    glutMouseFunc (mouse);
	init(); 
	glutMainLoop();
}


