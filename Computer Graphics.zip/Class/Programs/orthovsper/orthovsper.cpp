/* ortho and perspective viewing with a changing camera position */

#include <stdlib.h>
#include <iostream>
#include <GL/glut.h>
using namespace std;

char text[25];
GLfloat vertices[][3] = {{-1.0,-1.0,-1.0}, {1.0,-1.0,-1.0},
    {1.0,1.0,-1.0}, {-1.0,1.0,-1.0}, {-1.0,-1.0,1.0},
    {1.0,-1.0,1.0}, {1.0,1.0,1.0}, {-1.0,1.0,1.0}};
GLfloat colors[][3] = {{0.0,0.0,0.0}, {1.0,0.0,0.0},
    {1.0,1.0,0.0}, {0.0,1.0,0.0}, {0.0,0.0,1.0},
    {1.0,0.0,1.0}, {1.0,1.0,1.0}, {0.0,1.0,1.0}};
GLfloat m[16];

GLubyte cubeIndices[]={0,3,2,1, 2,3,7,6, 0,4,7,3, 1,2,6,5, 4,5,6,7, 0,1,5,4};

int VIEW = 0;

GLfloat EYEX=-1.5;
GLfloat EYEY=1.5;
GLfloat EYEZ=1.5;

void display_output(char *string_to_display, void *font)
{
	int length, i;
	glRasterPos3f(-1., 1., 1.);	
	length = static_cast<int> (strlen(string_to_display));

	//Loop through and display each character
	for (i = 0; i < length; i++) 
	{
		glutBitmapCharacter(font, string_to_display[i]);
	}
}

void display()
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glDrawElements(GL_QUADS, 24, GL_UNSIGNED_BYTE, cubeIndices);
	glPolygonMode(GL_FRONT, GL_LINE);
	glLineWidth(3);
	glShadeModel(GL_FLAT);
	glDrawElements(GL_QUADS, 24, GL_UNSIGNED_BYTE, cubeIndices);
	glPolygonMode(GL_FRONT, GL_FILL);
	glShadeModel(GL_SMOOTH);
	glColor3f(0.0, 0.0, 0.0); 
	display_output(text, GLUT_BITMAP_HELVETICA_18);
	glutSwapBuffers();
}

void mouse(int btn, int state, int x, int y)
{
	if(btn==GLUT_RIGHT_BUTTON && state == GLUT_DOWN) 
	{
		EYEX = EYEX -.25;
		EYEY = EYEY + .25;
		EYEZ = EYEZ + .25;
	}

	if(btn==GLUT_LEFT_BUTTON && state == GLUT_DOWN)
	{
		if (VIEW == 0)		//cyan corner, gluLookAt, ortho
		{
			glMatrixMode(GL_PROJECTION);
			glLoadIdentity();
			glOrtho(-2.0, 2.0, -2.0, 2.0, -10.0, 10.0);
            glMatrixMode(GL_MODELVIEW);
			glLoadIdentity();
			sprintf_s(text, "%s %4.2f %4.2f %4.2f", "Ortho", EYEX, EYEY, EYEZ);
			gluLookAt(EYEX, EYEY, EYEZ,    -1.0, 1.0, 1.0,    0.0, 1.0, 0.0);
//			gluLookAt(0, 0, 0,    -1.0, 1.0, 1.0,    0.0, 1.0, 0.0);
			VIEW = 1;
		}
		else				//cyan corner, gluLookAt, perspective	
		{
			glMatrixMode(GL_PROJECTION);
			glLoadIdentity();
			gluPerspective(90, 1, .5, 5);
            glMatrixMode(GL_MODELVIEW);
			glLoadIdentity();						
			sprintf_s(text, "%s", "Per");
			sprintf_s(text, "%s %4.2f %4.2f %4.2f", "Per", EYEX, EYEY, EYEZ);
			gluLookAt(EYEX, EYEY, EYEZ,    -1.0, 1.0, 1.0,    0.0, 1.0, 0.0);
//			gluLookAt(0, 0, 0,  -1.0, 1.0, 1.0,    0.0, 1.0, 0.0);
			VIEW = 0;
		}
    	glutPostRedisplay();
	}
}

void myReshape(int w, int h)
{
	glutReshapeWindow(600,600);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(-2.0, 2.0, -2.0,  2.0, -10.0, 10.0);
    glMatrixMode(GL_MODELVIEW);
}

int main(int argc, char **argv)
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
	glutInitWindowSize(600, 600);
	glutCreateWindow("Ortho and Perspective Views");
	glutReshapeFunc(myReshape);
	glutDisplayFunc(display);
	glutMouseFunc(mouse);
	glEnable(GL_DEPTH_TEST); /* Enable hidden--surface--removal */
	glEnableClientState(GL_COLOR_ARRAY);
	glEnableClientState(GL_VERTEX_ARRAY);
	glVertexPointer(3, GL_FLOAT, 0, vertices);
	glColorPointer(3,GL_FLOAT, 0, colors);
	glClearColor (1.0, 1.0, 1.0, 1.0);
	glutMainLoop();
}
