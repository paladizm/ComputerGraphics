#include <iostream>
#include <GL/glut.h>
using namespace std;

void myinit() 
{
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(-250.0, 250.0, 0, 800, -1.0, 1.0);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
    glClearColor (0.9, 1.0, 1.0, 1.0);
}

void mouse(int btn, int state, int x, int y) 
{
	if (btn==GLUT_MIDDLE_BUTTON && state == GLUT_UP)
	{
		cout << "\nWindow coordinates of mouse: (" << x << " , " <<
			400-y << ")" << endl;
		cout << "World coordinates of mouse:  (" << x-250 << " , " << 
			(400-y)*2 << ")" << endl;
	}
}


void display() 
{
    glClear(GL_COLOR_BUFFER_BIT);
	//For reference, put lines that cross in the center
	glColor3f(0,0,0);
	glLineWidth(4);
	glBegin(GL_LINES);
		glVertex2f(0,0);
		glVertex2f(0,800);
		glVertex2f(-250,400);
		glVertex2f(250,400);
	glEnd();
	glFlush();
}

int main(int argc, char** argv) 
{
    glutInit(&argc,argv);
	glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);
	glutInitWindowPosition(100,200); 
	glutInitWindowSize(500,400);  
    glutCreateWindow("Test");
	glutDisplayFunc(display);    
	glutMouseFunc(mouse);
	myinit ();
	glutMainLoop();
}
