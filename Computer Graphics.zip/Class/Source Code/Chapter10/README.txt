This folder contains the following C programs that support Chapter 10:

robot.c: wire frame model of robot with two arms. Joint angle changed from menu

figure.c: figure tranversed directly in application, pushing and poping
matrices and attributes as necessary.

figuretr.c figure traversal by a generic tree visiting function

dynamic.c: similar to figuretr.c but uses dynamic tree nodes.
