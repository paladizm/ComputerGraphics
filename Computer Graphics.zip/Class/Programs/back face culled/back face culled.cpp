//clockwise vs counter-clockwise listing of vertices
#include <GL/glut.h>

void display()
{
    glClear (GL_COLOR_BUFFER_BIT);
	glColor3f (.1176, .565, 1.0);		//Set color to a blue
    glBegin(GL_POLYGON);				//Vertices counter clockwise
       glVertex2f(25,25);
       glVertex2f(-25,25);
       glVertex2f(-25,-25);
       glVertex2f(25,-25);
    glEnd();
    
	glColor3f(1.0, 0.0, 0.0);			//Set Color to red
	glBegin(GL_POLYGON);				//Vertices clockwise
       glVertex2f(100,25);
       glVertex2f(100,-25);
       glVertex2f(50,-25);
       glVertex2f(50,25);
    glEnd();

    glFlush();
}


void myinit ()
{
    glClearColor (0.941, 0.973, 1.0, 1.0);
    glShadeModel (GL_FLAT);
	glPolygonMode (GL_FRONT, GL_FILL);	//The default
//	glPolygonMode (GL_BACK, GL_LINE);
    glLineWidth(3);
	
//	glEnable(GL_CULL_FACE);
//	glCullFace(GL_BACK);

	glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
	glOrtho (-50.0, 125.0, -50.0, 50.0, -50.0, 50.0);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity ();

}

int main(int argc, char** argv)
{
    glutInit(&argc,argv);
    glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);
	glutInitWindowSize(700,400);    	
	glutCreateWindow("Two Polygons");
    myinit ();
    glutDisplayFunc(display);
    glutMainLoop();
}
