/*twotimers.cpp
 *  This program spins squares in two different windows, one
 *  at a rate that is four times the other
 */

#include <stdlib.h>
#include <GL/glut.h>
#include <math.h>

#define DEGREES_TO_RADIANS 3.14159/180.0

static GLfloat spins = 0.0, spinf = 0.0;
GLfloat xs, ys, xf, yf;
int slow, fast;
GLint TIMER = 800;

//Function to define a square
void square(GLfloat x, GLfloat y)
{
    glBegin(GL_QUADS);
	   glVertex2f(x,y);
	   glVertex2f(-y,x);
       glVertex2f(-x,-y);
	   glVertex2f(y,-x);
	glEnd();
}

//Display callback:  Draws the square for the "fast" window
void displayf()
{
    glClear (GL_COLOR_BUFFER_BIT);
    square(xf,yf);
    glutSwapBuffers ();
}

//Display callback:  Draws the square for the "slow" window
void displays()
{
    glClear (GL_COLOR_BUFFER_BIT);
    square(xs,ys);
    glutSwapBuffers();
}

//Timer callback.  Depending on which timer has gone off either the
//"fast" square is rotated or the "slow" square is rotated.
void mytimer(int id)
{
	if (id == 0)
	{
	    spins = spins + 2.0;
		if (spins > 360.0) spins = spins - 360.0;
		xs= 25.0*cos(DEGREES_TO_RADIANS * spins);
		ys= 25.0*sin(DEGREES_TO_RADIANS * spins);
		glutSetWindow(slow);
		glutPostRedisplay();
		glutTimerFunc(TIMER, mytimer, 0);
	}
	else
	{
	    spinf = spinf + 2.0;
		if (spinf > 360.0) spinf = spinf - 360.0;
		xf = 25.0*cos(DEGREES_TO_RADIANS * spinf);
		yf = 25.0*sin(DEGREES_TO_RADIANS * spinf);
		glutSetWindow(fast);
		glutPostRedisplay();
		glutTimerFunc(TIMER/4, mytimer, 1);
	}
}

//Usual initialization
void myinit ()
{
    glClearColor (0.0, 0.0, 0.0, 1.0);
    glColor3f (1.0, 1.0, 1.0);
    glShadeModel (GL_FLAT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
	glOrtho (-50.0, 50.0, -50.0, 50.0, -1.0, 1.0);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity ();
}

int main(int argc, char** argv)
{
	glutInit(&argc,argv);

	//Set up for and open the window for slower animation
	glutInitDisplayMode (GLUT_DOUBLE | GLUT_RGB);
	slow=glutCreateWindow("slower");
    myinit ();
	glutDisplayFunc(displays); 
    glutTimerFunc(TIMER,mytimer,0);

	//Set up for and open the window for faster animation
	glutInitDisplayMode (GLUT_DOUBLE | GLUT_RGB);
    glutInitWindowPosition(500,0);
	fast=glutCreateWindow("faster");
    myinit ();
    glutTimerFunc(TIMER/4,mytimer,1);
	glutDisplayFunc(displayf);

	glutMainLoop();	//Turn everything over to the event handler
}

