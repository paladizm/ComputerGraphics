//perspective.cpp
//This is a program to generate a perspective view of the standard
//color cube.

#include <stdlib.h>
#include <cmath>
#include <iostream>
#include <iomanip>
#include <GL/glut.h>
using namespace std;

GLfloat vertices[][3] = {{-1.0,-1.0,-1.0}, {1.0,-1.0,-1.0},
   {1.0,1.0,-1.0}, {-1.0,1.0,-1.0}, {-1.0,-1.0,1.0},
   {1.0,-1.0,1.0}, {1.0,1.0,1.0}, {-1.0,1.0,1.0}};

GLfloat colors[][3] = {{0.0,0.0,0.0},{1.0,0.0,0.0},
   {1.0,1.0,0.0}, {0.0,1.0,0.0}, {0.0,0.0,1.0},
   {1.0,0.0,1.0}, {1.0,1.0,1.0}, {0.0,1.0,1.0}};

GLubyte cubeIndices[]={0,3,2,1, 2,3,7,6, 0,4,7,3, 1,2,6,5, 4,5,6,7, 0,1,5,4};

GLfloat FOVY = 30;
GLfloat FAR = 10;
GLfloat NEAR = 2;
bool show = true;

void display()
{
   glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
   glLoadIdentity();
   glTranslatef(0,0,-4);
   glRotatef(35.26, 1, 0, 0);
   glRotatef(45, 0, 1, 0);
   glDrawElements(GL_QUADS, 24, GL_UNSIGNED_BYTE, cubeIndices);
   glutSwapBuffers();
}


void mouse(int btn, int state, int x, int y)
{
	//Need to go into matrix mode for projection to do anything
	//with perspective or ortho
	if(btn == GLUT_LEFT_BUTTON && state == GLUT_DOWN)
	{
		glMatrixMode(GL_PROJECTION);
		glLoadIdentity();
		FOVY = FOVY + 10;
		cout << "fovy = " << FOVY << endl;
		gluPerspective(FOVY,1, NEAR, FAR);
		
		if (show)
		{
			float m[16];						// space for a 4 by 4 matrix
			glGetFloatv(GL_PROJECTION_MATRIX, m);
			cout << "\nProjection Matrix " << endl;
			for (int i=0; i<4; i++)
			{
				cout << setw(8) << m[i] << setw(8) << m[i+4]<< setw(8) 
					<< m[i+8]<< setw(8) << m[i+12] << endl;
			}
		}
		glMatrixMode(GL_MODELVIEW);
		glutPostRedisplay();
	}
	else if (btn == GLUT_RIGHT_BUTTON && state == GLUT_DOWN)
	{	
		glMatrixMode(GL_PROJECTION);
		glLoadIdentity();
		glOrtho(-2, 2, -2, 2, NEAR, FAR);
		glMatrixMode(GL_MODELVIEW);
		glutPostRedisplay();
	}

}

void myReshape(int w, int h)
{
   glViewport(0, 0, w, h);
   glMatrixMode(GL_PROJECTION);
   glLoadIdentity();
   gluPerspective(FOVY, 1, NEAR, FAR); 
   glMatrixMode(GL_MODELVIEW);
   glLoadIdentity();
}

int main(int argc, char **argv)
{
	cout.setf(ios::fixed);
	cout.setf(ios::showpoint);
	cout.precision(2);
   glutInit(&argc, argv);
   glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
   glutInitWindowSize(500, 500);
   glutCreateWindow("Perspective colorcube");
   glutReshapeFunc(myReshape);
   glutDisplayFunc(display);
   glutMouseFunc(mouse);
   glEnable(GL_DEPTH_TEST); /* Enable hidden--surface--removal */
   glEnableClientState(GL_COLOR_ARRAY);
   glEnableClientState(GL_VERTEX_ARRAY);
   glVertexPointer(3, GL_FLOAT, 0, vertices);
   glColorPointer(3,GL_FLOAT, 0, colors);
   glClearColor(1,1,1,1);
   glutMainLoop();
}
