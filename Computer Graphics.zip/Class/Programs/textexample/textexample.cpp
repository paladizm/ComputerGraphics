//textexample.cpp
#include <iostream>
#include <fstream>
#include <string>
using namespace std;

#include <GL/glut.h>

GLdouble xmin, xmax, ymin, ymax;

//Routine to display a string in the specified font at position (x,y,z) in world
//coordiates 
void display_output(char *string_to_display, void *font, GLint x, GLint y, GLint z)
{
  int length, i;

  glRasterPos3f(x, y, 0);		//Need to "go to" the specified postion in the raster
								//w/o this text would be displayed next to the last
								//object rendered

  length = static_cast<int> (strlen(string_to_display));

  //Loop through and display each character
  for (i = 0; i < length; i++) 
  {
    glutBitmapCharacter(font, string_to_display[i]);
  }
}

//Display callback.  Displays "hello" in bottom left corner, "HI" beginning in the center
//of the window and the value of xmin in the bottom right quadrant
void mydisplay()
{
	char text[10];

	glClear(GL_COLOR_BUFFER_BIT);

	glColor3f(0.0, 0.0, 0.0); 
	sprintf(text,"%s","hello" );
	display_output(text, GLUT_BITMAP_HELVETICA_18, xmin,ymin,0);

	glColor3f(1.0, .25, 0.0); 
	sprintf(text,"%s", "HI");
	display_output(text, GLUT_BITMAP_HELVETICA_18, xmin+(xmax-xmin)/2.0,ymin+(ymax-ymin)/2.0,0);
	
	//This illustrates why the sprintf is useful
	glColor3f(0.0, .25, 1.0); 
	sprintf(text,"%.1f", xmin);
	display_output(text, GLUT_BITMAP_HELVETICA_18, xmin+(xmax-xmin)*.75,ymin+(ymax-ymin)/3.0,0);

	glFlush(); 
}


void init()
{
	glClearColor (0.98, 0.98, 0.98, 1.0);
	glMatrixMode (GL_PROJECTION);    
	glLoadIdentity ();    
	glOrtho(xmin, xmax, ymin, ymax, 0.0, 1.0); 
}


int main(int argc, char** argv)
{
	cout << "Please enter x range for the window: ";
	cin >> xmin >> xmax;
	cout << "Please enter the y range: ";
	cin >> ymin >> ymax;

	glutInit(&argc,argv); 
	glutInitDisplayMode(GLUT_SINGLE|GLUT_RGB); 

	glutInitWindowSize(700,300);    	
	glutInitWindowPosition(100,100); 
	glutCreateWindow("Say Hello");     
	glutDisplayFunc(mydisplay);  
  
	init(); 
   
	glutMainLoop();
}
