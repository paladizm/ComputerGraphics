//Illustration of Viewport

#include <GL/glut.h>

void mydisplay() 
{
	glClear(GL_COLOR_BUFFER_BIT);
	glColor3f(1,1,1);
	glPointSize(7);
	glBegin(GL_POINTS);
        glVertex2f(1.0, 1.0); 
        glVertex2f(1.0, 99.0); 
        glVertex2f(99.0, 1.0); 
        glVertex2f(99.0, 99.0); 
	glEnd();

	glColor3f(1.0, 0.0, 0.0); 
	glBegin(GL_TRIANGLE_STRIP); // draw in triangle strips
		glVertex2f(50.0, 87.5); 
        glVertex2f(25.0, 62.5); 
        glVertex2f(75.0, 62.5); 
        glVertex2f(25.0, 25.0); 
        glVertex2f(75.0, 25.0); 
	glEnd();
    glFlush();
}

void myreshape(int w, int h)
{
    glutReshapeWindow(400,400);
}


void init()
{
//    glViewport(50, 50, 300, 300);
	glClearColor (0.0, 0.0, 0.0, 1.0);
	glColor3f(1.0, 1.0, 1.0); 
	glMatrixMode (GL_PROJECTION);    
	glLoadIdentity ();    
	glOrtho(0, 100, 0, 100, 0, 100);  
	glMatrixMode (GL_MODELVIEW);    
	glLoadIdentity ();    
}


int main(int argc, char** argv)
{
	glutInit(&argc,argv); 
	glutInitDisplayMode(GLUT_SINGLE|GLUT_RGB);      
	glutInitWindowSize(400,400);    	
	glutInitWindowPosition(0,0); 
	glutCreateWindow("Red House");     
	glutDisplayFunc(mydisplay);  
	glutReshapeFunc(myreshape);  
	init(); 
   
	glutMainLoop();
}
