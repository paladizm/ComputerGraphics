//Illustrate some glut shapes
#include <GL/glut.h>

void mydisplay() 
{
	glClear(GL_COLOR_BUFFER_BIT);
	glColor3f(1.0, 0.0, 0.0); 

	//Set primary view
	glLoadIdentity();
	glRotatef(45, 1.0, 0.0, 0.0);
	glRotatef(45, 0.0, 1.0, 0.0);

	// big cube at (0.5, 0.5, 0.5)
	glPushAttrib(GL_ALL_ATTRIB_BITS);
	glPushMatrix();
	glTranslated(0.5, 0.5, 0.5); 
	glutWireCube(1.0);
	glPopMatrix();
	glPopAttrib();

	// small cube at (0,1,1)
	glPushAttrib(GL_ALL_ATTRIB_BITS);
	glPushMatrix();
	glColor3f(0.0, 0.0, 1.0); 
	glTranslated(0, 0.0 ,0.0); 
	glutWireCube(0.25);
	glPopMatrix();
	glPopAttrib();

	// teapot at (1,1,1).  Note there's no push/pop attrib
	glPushMatrix();
	glColor3f(0.0, 1.0, 0.0); 
	glTranslated(1,1,1);
	glutWireTeapot(0.2); 
	glPopMatrix();

	// sphere at (1,1,0)
	glPushMatrix();	
	glTranslated(1.0,1.0,0); 
	glutWireSphere(0.25, 10, 8);
	glPopMatrix();		

	//Solid Cube at (1,0,1)	
	glPushAttrib(GL_ALL_ATTRIB_BITS);
	glPushMatrix();	
	glColor3f(0.0, 1.0, 1.0); 
	glTranslated(1.0,0.0,1.0);
	glutSolidCube(0.15);
	glPopMatrix();
	glPopAttrib();

	//Cone at (1,0,0)	
	glPushAttrib(GL_ALL_ATTRIB_BITS);
	glPushMatrix();	
	glColor3f(0.0, 0.0, 0.0); 
	glTranslated(1.0,0.0,0.0);
	glutWireCone(0.2, 0.5, 10, 8);
	glPopMatrix();
	glPopAttrib();

    glFlush();
}

void init()
{
	glClearColor (0.95, 0.95, 0.95, 1.0);
	glMatrixMode (GL_PROJECTION);    
	glLoadIdentity ();    
	glOrtho(-1, 2.5, -1, 2.5, -2, 4);  
	glMatrixMode (GL_MODELVIEW);    
	glLoadIdentity ();    
}

int main(int argc, char** argv)
{
	glutInit(&argc,argv); 
	glutInitDisplayMode(GLUT_SINGLE|GLUT_RGB);      
	glutInitWindowSize(600,600);    	
	glutInitWindowPosition(0,0); 
	glutCreateWindow("some glut shapes");     
	glutDisplayFunc(mydisplay);  
	init(); 
	glutMainLoop();
}
