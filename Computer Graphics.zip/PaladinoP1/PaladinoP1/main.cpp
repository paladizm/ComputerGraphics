// PaladinoP1
// Zac Paladino, cps460-01.16, 2D Project
// Dots and Boxes
// March 23, 2009

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <ctime>
#include <math.h>
#include<vector>
#include <windows.h>
#include <GL/glut.h>
using namespace std;

//This is the Line structure for all the edges in the game.
struct Line{
	GLfloat FirstXP, FirstYP, SecXP, SecYP;
	GLfloat Xmax,Ymax,Xmin,Ymin;
	bool picked;
	GLint Player;
};
//This is the Square structure and holds the placement of winning
//squares and who won it.
struct Square{
	GLfloat x1,x2,x3,x4,y1,y2,y3,y4;
	//These represent which edges are taken and if
	//all are true created is set to true which mean a
	//square was taken.
	bool v1,v2,v3,v4,created;
	GLint Player;
};

//These are the primary data structures.
//This is a 2D vector array of vertical edges for the game.
vector<vector<Line>> VLines;
//This is a 2D vector array of horizontal edges for the game.
vector<vector<Line>> HLines;
//This is a vector array that holds all the infromation for the squares.
vector<Square> Squares;

//Window height and Width.
GLint WH = 500, WW = 500;
//Number of boxes for the game so it would be a NxN grid.
GLint NUMBOX = 4;
//PICFAC deals with the mouse picking factor, and both SQUAREANI's
//deal with the animation of the squares.
GLfloat PICFAC,SQUAREANI = 1.0, SQUAREANI2 = 1.0;

//These are the colors to choose from.
GLfloat colors[8][3]={{0.0, 0.0, 0.0}, {1.0, 0.0, 0.0},{0.0, 1.0, 0.0},
    {0.0, 0.0, 1.0}, {0.0, 1.0, 1.0}, {1.0, 0.0, 1.0}, {1.0, 1.0, 0.0},
    {1.0, 1.0, 1.0}};
//These globals set the Players colors, turn, points, and the points.
GLint P1COLOR = 1, P2COLOR = 3, TURN = 0, TIMER=100, P1POINT = 0, P2POINT = 0;
//These booleans help with animation and Winning the game.
bool REVERSE=false, WIN=false,REVERSE2=false;


//display_text is the helper function that displays the text for the game.
void display_text(char *string_to_display, void *font, GLint x, GLint y, GLint z){
  int length, i;
  glRasterPos3f(x, y, 0);	
  length = static_cast<int> (strlen(string_to_display));
  for (i = 0; i < length; i++){
    glutBitmapCharacter(font, string_to_display[i]);
  }
}
//DrawTxt displays all the text for the game, shows the score, and who wins.
void DrawTxt(){
	char text[30];
	glColor3f(0.0, 0.0, 0.0); 
	sprintf_s(text,"%s","Dots and Boxes!" );
	display_text(text, GLUT_BITMAP_TIMES_ROMAN_24,(((NUMBOX*10)+((NUMBOX*10)/2))/3)
		,((((NUMBOX*10)+((NUMBOX*10)/2)))-((NUMBOX*10)+((NUMBOX*10)/2))/10),0);
	glColor3f(colors[P1COLOR][0],colors[P1COLOR][1],colors[P1COLOR][2]);
	sprintf_s(text,"%s","Player1" );
	display_text(text, GLUT_BITMAP_TIMES_ROMAN_24,0
		,((NUMBOX*10)+((NUMBOX*10)/2))/2,0);
	sprintf_s(text,"%s%d","     ", P1POINT );
	display_text(text, GLUT_BITMAP_TIMES_ROMAN_24,0
		,((((NUMBOX*10)+((NUMBOX*10)/2))/2)-NUMBOX),0);
	glColor3f(colors[P2COLOR][0],colors[P2COLOR][1],colors[P2COLOR][2]);
    sprintf_s(text,"%s"," Player2" );
	display_text(text, GLUT_BITMAP_TIMES_ROMAN_24,(VLines[NUMBOX-1][NUMBOX-1].FirstXP+10)
		,((NUMBOX*10)+((NUMBOX*10)/2))/2,0);
	sprintf_s(text,"%s%d","     ",P2POINT );
	display_text(text, GLUT_BITMAP_TIMES_ROMAN_24,(VLines[NUMBOX-1][NUMBOX-1].FirstXP+10)
		,(((NUMBOX*10)+((NUMBOX*10)/2))/2)-NUMBOX,0);
	if(WIN){
		//This helps in displaying who won and in the correct color.
		int temp, temp2;
		if(P1POINT>P2POINT){
			temp=P1COLOR;
			temp2=1;
		}
		else{
			temp=P2COLOR;
			temp2=2;
		}
		glColor3f(colors[temp][0],colors[temp][1],colors[temp][2]);
		sprintf_s(text,"%s%d%s","Player ", temp2 ," WINS!" );
		display_text(text, GLUT_BITMAP_TIMES_ROMAN_24,(((NUMBOX*10)+((NUMBOX*10)/2))/3)
			,(((NUMBOX*10)+((NUMBOX*10)/2))/10),0);
	}
}

//DrawDots Displays all the dots inbetween intersections for the game.
void DrawDots(){
	glPointSize(5);
	glColor3f(0,0,0);
    glBegin(GL_POINTS);	   
	   for(int i=0; i<(NUMBOX+1); i++){
		 for(int j=0; j<NUMBOX; j++){
			glVertex3f((HLines[i][j].FirstXP),(HLines[i][j].FirstYP),1);
			glVertex3f((HLines[i][j].SecXP),(HLines[i][j].SecYP),1);					
		 }
	   }		
	glEnd();
}

//DrawSquares draws all the availiable squares with the correct color and
//placement according to the vector Squares.
void DrawSquares(){
	if(!Squares.empty()){
		for(int i=0; i<static_cast<int>(Squares.size()); i++){
			if(Squares[i].Player==1){
				glBegin(GL_POLYGON);
				    //SQUAREANI is the adjustment for animation.
					glColor3f(colors[P1COLOR][0],colors[P1COLOR][1],colors[P1COLOR][2]);
					glVertex3f(Squares[i].x1+SQUAREANI,Squares[i].y1+SQUAREANI,0);
					glVertex3f(Squares[i].x2-SQUAREANI,Squares[i].y2+SQUAREANI,0);					
					glVertex3f(Squares[i].x3-SQUAREANI,Squares[i].y3-SQUAREANI,0);
					glVertex3f(Squares[i].x4+SQUAREANI,Squares[i].y4-SQUAREANI,0);					
				glEnd();
			}
			else if(Squares[i].Player==2){
				glBegin(GL_POLYGON);
					glColor3f(colors[P2COLOR][0],colors[P2COLOR][1],colors[P2COLOR][2]);
					glVertex3f(Squares[i].x1+SQUAREANI,Squares[i].y1+SQUAREANI,0);
					glVertex3f(Squares[i].x2-SQUAREANI,Squares[i].y2+SQUAREANI,0);						
					glVertex3f(Squares[i].x3-SQUAREANI,Squares[i].y3-SQUAREANI,0);
					glVertex3f(Squares[i].x4+SQUAREANI,Squares[i].y4-SQUAREANI,0);
				glEnd();
			}
		}
	}
}

//DrawLines creates all the edges for the game with the correct color and placement.
void DrawLines(){	
	glBegin(GL_LINES);	   
	   for(int i=0; i<(NUMBOX+1); i++){
		 for(int j=0; j<NUMBOX; j++){
			if(HLines[i][j].picked){
				if(HLines[i][j].Player == 1){					
					glColor3f(colors[P1COLOR][0],colors[P1COLOR][1],colors[P1COLOR][2]);
					glVertex3f(HLines[i][j].FirstXP,HLines[i][j].FirstYP,0);
					glVertex3f(HLines[i][j].SecXP,HLines[i][j].SecYP,0);
				}
				else{					
					glColor3f(colors[P2COLOR][0],colors[P2COLOR][1],colors[P2COLOR][2]);
					glVertex3f(HLines[i][j].FirstXP,HLines[i][j].FirstYP,0);
					glVertex3f(HLines[i][j].SecXP,HLines[i][j].SecYP,0);
				}
			}
			else{				
				glColor3f(.9,.9,.9);
				glVertex3f(HLines[i][j].FirstXP,HLines[i][j].FirstYP,0);
				glVertex3f(HLines[i][j].SecXP,HLines[i][j].SecYP,0);
			}


		    if(VLines[i][j].picked){
				if(VLines[i][j].Player == 1){					
					glColor3f(colors[P1COLOR][0],colors[P1COLOR][1],colors[P1COLOR][2]);
					glVertex3f(VLines[i][j].FirstXP,VLines[i][j].FirstYP,0);
					glVertex3f(VLines[i][j].SecXP,VLines[i][j].SecYP,0);	
				}
				else{					
					glColor3f(colors[P2COLOR][0],colors[P2COLOR][1],colors[P2COLOR][2]);
					glVertex3f(VLines[i][j].FirstXP,VLines[i][j].FirstYP,0);
					glVertex3f(VLines[i][j].SecXP,VLines[i][j].SecYP,0);	
				}
			}
			else{				
				glColor3f(.9,.9,.9);
				glVertex3f(VLines[i][j].FirstXP,VLines[i][j].FirstYP,0);
				glVertex3f(VLines[i][j].SecXP,VLines[i][j].SecYP,0);	
			}	
		 }
	   }
	glEnd();
}
//DisplayTurn displays the turn of the player by color in the upper right
//corner.
void DisplayTurn(){
	GLint temp = 0;
	if (TURN == 0){
		temp = P1COLOR;
	}
	else{
		temp = P2COLOR;
	}
	glBegin(GL_POLYGON);
		glColor3f(colors[temp][0],colors[temp][1],colors[temp][2]);
		glVertex3f(0,((NUMBOX*10)+((NUMBOX*10)/2)),0);
		glVertex3f(NUMBOX,((NUMBOX*10)+((NUMBOX*10)/2)),0);
		glVertex3f(NUMBOX,((NUMBOX*10)+((NUMBOX*10)/2))-NUMBOX,0);
		glVertex3f(0,((NUMBOX*10)+((NUMBOX*10)/2))-NUMBOX,0);
	glEnd();
}

//DisplayWin calculates if the game is over and if it is a square is animated
//with the color of that player over the entire board and WIN is set to true.
void DisplayWin(){
	int count=0, PlayWin=0;
	for(int i = 0; i<(NUMBOX*NUMBOX); i++){
		if(Squares[i].created){
			count++;
		}
	}
	if(count == (NUMBOX*NUMBOX)){
		WIN = true;
		if(P1POINT>P2POINT){
			PlayWin=1;
		}
		else{
			PlayWin=2;
		}
	}
	if(WIN){
		GLint temp = 0;
		if (PlayWin == 1){
			temp = P1COLOR;
		}
		else{
			temp = P2COLOR;
		}
		glBegin(GL_POLYGON);
		    //SQUAREANI2 deals with the animation of the large square.
			glColor3f(colors[temp][0],colors[temp][1],colors[temp][2]);
			glVertex3f(VLines[0][NUMBOX-1].FirstXP+SQUAREANI2,VLines[0][NUMBOX-1].SecYP-SQUAREANI2,3);
			glVertex3f(VLines[NUMBOX][NUMBOX-1].FirstXP-SQUAREANI2,VLines[NUMBOX][NUMBOX-1].SecYP-SQUAREANI2,3);						
			glVertex3f(VLines[NUMBOX][NUMBOX-1].FirstXP-SQUAREANI2,VLines[NUMBOX][0].FirstYP+SQUAREANI2,3);	
			glVertex3f(VLines[0][0].FirstXP+SQUAREANI2,VLines[0][0].FirstYP+SQUAREANI2,3);
	     glEnd();
	}
}

//myDisplay displays the game.	
void myDisplay(){
	glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);	
	DrawTxt();
    DrawDots();
	DrawLines();
	DrawSquares();
	DisplayTurn();
	DisplayWin();
	glutSwapBuffers();
}
//CreateGrid calculates the size and shape of the grid and sets up all the data structs.
void CreateGrid(){
	//initalizes the Squares vector. 
	for(int i=0; i<(NUMBOX*NUMBOX);i++){
		Square news;
		news.v1 = false;
		news.v2 = false;
		news.v3 = false;
		news.v4 = false;
		news.created =false;
		news.x1 = -1.0;
		news.x2 = -1.0;
		news.x3 = -1.0;
		news.x4 = -1.0;
		news.y1 = -1.0;
		news.y2 = -1.0;
		news.y3 = -1.0;
		news.y4 = -1.0;
		news.Player = 0;
		Squares.push_back(news);
	}
    //Creates the grid to glOrthos specification of world coords.
	//each edge is 10px long. This also sets up HLines and VLines data structs
	GLfloat x = ((((NUMBOX*10)/2))-(NUMBOX*10/4)), y =((((NUMBOX*10)/2))-(NUMBOX*10/4));
	for(int i = 0; i<(NUMBOX+1); i++){
		vector<Line> Htemp;
		for(int j=0; j<NUMBOX; j++){
			Line newHL;			
			newHL.FirstXP = x;
			newHL.FirstYP = y;
			newHL.Xmin=x;
			newHL.Ymin=y-.5;
			x += 10.0;
			newHL.SecXP = x;
			newHL.SecYP = y;
			newHL.picked=false;
			newHL.Player=0;	
			newHL.Xmax=x;
			newHL.Ymax=y+.5;			
			Htemp.push_back(newHL);
		}
		HLines.push_back(Htemp);		
		y+=10.0;
		x=((((NUMBOX*10)/2))-(NUMBOX*10/4));
	}
	x=((((NUMBOX*10)/2))-(NUMBOX*10/4));
	y=((((NUMBOX*10)/2))-(NUMBOX*10/4));
	for(int i = 0; i<(NUMBOX+1); i++){
		vector<Line> Vtemp;
		for(int j=0; j<NUMBOX; j++){
			Line newVL;			
			newVL.FirstXP = x;
			newVL.FirstYP = y;
			newVL.Xmin=x-.5;
			newVL.Ymin=y;
			y += 10.0;
			newVL.SecXP = x;
			newVL.SecYP = y;
			newVL.picked=false;
			newVL.Xmax=x+.5;
			newVL.Ymax=y;
			newVL.Player=0;			
			Vtemp.push_back(newVL);
		}
		VLines.push_back(Vtemp);		
		x+=10.0;
		y=((((NUMBOX*10)/2))-(NUMBOX*10/4));
	}
	//creates the squares in advance and stores them in squares.
	//the data comes from the edge data. 
	int place=0;	
	for(int z=0; z<NUMBOX;z++){
		for(int k=0; k<(NUMBOX+1);k++){			
			if(place<(NUMBOX*NUMBOX)){
				if(k<NUMBOX){
					Squares[place].x1 = HLines[k][z].FirstXP;
					Squares[place].y1 = HLines[k][z].FirstYP;
					Squares[place].x2 = HLines[k][z].SecXP;
					Squares[place].y2 = HLines[k][z].SecYP;
				}
				if((k+1)<(NUMBOX+1)){
					Squares[place].x3 = HLines[k+1][z].SecXP;
					Squares[place].y3 = HLines[k+1][z].SecYP;
					Squares[place].x4 = HLines[k+1][z].FirstXP;
					Squares[place].y4 = HLines[k+1][z].FirstYP;
				}				
			}
			if(k<NUMBOX){
				place++;
			}
		}
	}
}

//createSquare takes the infromation from picking and sees if the edge
//that was just picked created a square if it did it changes the Squares
//data struct at the right index to created. vh is vertical or horizontal and
//if it is 1 that means that a horizontal edge was picked else a vertical edge
//was. If all of the points match that edge the edge is then set to true.
bool createSquare(int i, int j,int Player, int vh){
	bool squaremade = false;
	for(int z = 0; z<(NUMBOX*NUMBOX); z++){
		if(!Squares[z].created){
			if (vh == 1){
				if(Squares[z].x1 == HLines[i][j].FirstXP && 
					Squares[z].y1 == HLines[i][j].FirstYP){
					if(Squares[z].x2==HLines[i][j].SecXP
						&& Squares[z].y2 == HLines[i][j].SecYP){
						Squares[z].v1 = true; //first edge set to true
					}
				}
				if(Squares[z].x4 == HLines[i][j].FirstXP &&
					Squares[z].y4 == HLines[i][j].FirstYP){
					if(Squares[z].x3==HLines[i][j].SecXP &&
						Squares[z].y3 == HLines[i][j].SecYP){
						Squares[z].v3 = true; //third edge set to true
					}
				}
			}
			else{
				if(Squares[z].x3 == VLines[i][j].SecXP &&
					Squares[z].y3 == VLines[i][j].SecYP){
					if(Squares[z].x2==VLines[i][j].FirstXP &&
						Squares[z].y2 == VLines[i][j].FirstYP){
						Squares[z].v2 = true; //sec edge set to true
					}
				}
				if(Squares[z].x1 == VLines[i][j].FirstXP &&
					Squares[z].y1 == VLines[i][j].FirstYP){
					if(Squares[z].x4==VLines[i][j].SecXP &&
						Squares[z].y4 == VLines[i][j].SecYP){
						Squares[z].v4 = true; //fourth edge set to true
					}
				}
			}
			//If all edges are true the square is now created.
			if(Squares[z].v1&&Squares[z].v2&&Squares[z].v3&&Squares[z].v4){
				Squares[z].Player=Player;
				Squares[z].created=true;
				squaremade = true;
			}
		}
	}
	return squaremade;
}

//myMouse deals with the selection of edges.
void myMouse(int btn, int state, int x, int y){
	//invert y.
	y = WH-y;
	//create world x and world y mouse coords.
	GLfloat nx = (x/PICFAC), ny = (y/PICFAC);
	if(btn==GLUT_LEFT_BUTTON && state==GLUT_DOWN){
	   bool pick=false;
	   //loops through the horizontal and vertical
	   //edges to see if the mouse picked it.
	   for(int i=0; i<(NUMBOX+1); i++){
		 for(int j=0; j<NUMBOX; j++){
			 //if it is not picked and inside the world coords it will be picked.
			 if(!HLines[i][j].picked){				
				 if((nx>=HLines[i][j].Xmin)&&(nx<=HLines[i][j].Xmax)&&
					 (ny>=(HLines[i][j].Ymin))&&(ny<=(HLines[i][j].Ymax))){
					 //if it is the first players turn it changes the
					 //color and infromation accordingly.
					 if(TURN==0){						
						 HLines[i][j].picked=true;
						 HLines[i][j].Player = 1;
						 pick = true;
						 //if a square was created the turn does not change.
						 if(createSquare(i,j,1,1)){
							 TURN=0;							 
						 }
						 else{
							TURN=1;
						 }
						 glutPostRedisplay();	
						 //if it was picked get out.
						 break;						
					 }
					 else{						 
						 HLines[i][j].picked=true;
						 HLines[i][j].Player = 2;
						 pick = true;
						 if(createSquare(i,j,2,1)){
							 TURN=1;							 
						 }
						 else{
							TURN=0;
						 }
						 glutPostRedisplay();						 
						 break;						
					 }
				 }
			 }
			 if(!pick && !VLines[i][j].picked){				 
				 if((nx>=VLines[i][j].Xmin)&&(nx<=VLines[i][j].Xmax)&&
					 (ny>=(VLines[i][j].Ymin))&&(ny<=(VLines[i][j].Ymax))){
					 if(TURN==0){						 
						 VLines[i][j].picked=true;
						 VLines[i][j].Player = 1;
						 pick = true;
						 if(createSquare(i,j,1,0)){
							 TURN=0;
						 }
						 else{
							TURN=1;
						 }
						 glutPostRedisplay();
						 break;						 
					 }
					 else{						 
						 VLines[i][j].picked=true;
						 VLines[i][j].Player = 2;
						 pick = true;
						 if(createSquare(i,j,2,0)){
							 TURN=1;
						 }
						 else{
							TURN=0;
						 }
						 glutPostRedisplay();
						 break;
					 }
				 }
			 }
		 }
		 if(pick){
			 break;
		 }
	   }
	}
	//This adds up the points for the game.
	int temp1=0, temp2=0;
	for(int i=0; i<(NUMBOX*NUMBOX); i++){
		if(Squares[i].Player == 1){
			temp1++;
		}
		else if(Squares[i].Player == 2){
			temp2++;
		}
	}
	P1POINT = temp1;
	P2POINT = temp2;
}

//myTimer deals with the animation for the squares and
//the winning square.
void myTimer(int id){	
	if(SQUAREANI < 4 && !REVERSE){
		SQUAREANI += .5;
	}
	else{
		REVERSE = true;		
	}
	if(SQUAREANI > 1 && REVERSE){
		SQUAREANI -= .5;
	}
	else{
		REVERSE = false;		
	}
	if(WIN){
		if(SQUAREANI2 < 6 && !REVERSE2){
			SQUAREANI2 += .5;
		}
		else{
			REVERSE2 = true;		
		}
		if(SQUAREANI2 > 1 && REVERSE2){
			SQUAREANI2 -= .5;
		}
		else{
			REVERSE2 = false;		
		}
	}
	glutPostRedisplay();
	glutTimerFunc(TIMER, myTimer, 0);
}

//The reshape for this game is blocked.
void reshape(int w, int h){
    glutReshapeWindow(WH,WW);
}	

//Init sets up the view volume and asks how big of a grid and creates it.
void Init(){
	cout << "Please Enter Grid Size NxN (4-10): ";
	cin >> NUMBOX;
	if(NUMBOX<=0)
		NUMBOX=4;
	glClearColor(1.0,1.0,1.0,0);
	glEnable(GL_DEPTH_TEST);
	//creates the world coords.
	glOrtho(0,((NUMBOX*10)+((NUMBOX*10)/2)),0,((NUMBOX*10)+((NUMBOX*10)/2)),-5,((NUMBOX*10)+5));
	CreateGrid();
	//adjusts the picking factor.
	PICFAC = 500.0/((NUMBOX*10)+((NUMBOX*10)/2));
	//Starts the animation.
	glutTimerFunc(TIMER, myTimer, 0);
}
//NewGame clears the data structures and sets all the globals to
//their defaults. It then creates the grid again. 
void NewGame(){
	VLines.clear();
	HLines.clear();
	Squares.clear();
	WIN = false;
	REVERSE = false;
	REVERSE2 = false;
	P1POINT = 0;
	P2POINT = 0;
	TURN = 0;
    SQUAREANI = 1.0;
	SQUAREANI2 = 1.0;
	CreateGrid();
}

//color_menuP1 is the color menu change for P1
void color_menuP1(int index)
{
    if(index!=P2COLOR)
		P1COLOR = index; 
}

//color_menuP2 is the color menu change for P2
void color_menuP2(int index)
{
    if(index!=P1COLOR)
		P2COLOR = index; 
}

//main_menu deals with creating a NewGame and exiting.
void main_menu(int index){
	if(index==0){
		NewGame();
	}
	else if(index==1){
		exit(0);
	}
}
//Menu sets up the menu system.
void Menu(){
	int c_menu = glutCreateMenu(color_menuP1);
    glutAddMenuEntry("Black",0);
    glutAddMenuEntry("Red",1);
    glutAddMenuEntry("Green",2);
    glutAddMenuEntry("Blue",3);
    glutAddMenuEntry("Cyan",4);
    glutAddMenuEntry("Magenta",5);
    glutAddMenuEntry("Yellow",6);
	int c_menu2 = glutCreateMenu(color_menuP2);
    glutAddMenuEntry("Black",0);
    glutAddMenuEntry("Red",1);
    glutAddMenuEntry("Green",2);
    glutAddMenuEntry("Blue",3);
    glutAddMenuEntry("Cyan",4);
    glutAddMenuEntry("Magenta",5);
    glutAddMenuEntry("Yellow",6);

	glutCreateMenu(main_menu);
	glutAddSubMenu("P1 Color", c_menu);
	glutAddSubMenu("P2 Color", c_menu2);
	glutAddMenuEntry("New Game", 0);
	glutAddMenuEntry("Exit", 1);
	glutAttachMenu(GLUT_RIGHT_BUTTON);
}   

int main(int argc, char** argv)
{
	glutInit(&argc,argv); 
	glutInitDisplayMode(GLUT_DOUBLE|GLUT_RGB|GLUT_DEPTH);      
	glutInitWindowSize(WH,WW);    	
	glutInitWindowPosition(10,10); 
	glutCreateWindow("Zac Paladino - Dots");	
	Init();
	glutReshapeFunc(reshape);
	Menu();
	glutMouseFunc(myMouse);
	glutDisplayFunc(myDisplay);
	glutMainLoop();
	return 0;
}